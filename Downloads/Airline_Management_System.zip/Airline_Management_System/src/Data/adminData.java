package Data;


public class adminData {
    
     public static String adminUsername;
     public static String adminPassword;
    
    public adminData() {
        
        
        if (adminUsername != null && !adminUsername.isEmpty()) {
           
            } else adminUsername = "admin";
        
        
        
        if (adminPassword != null && !adminPassword.isEmpty()) {
        
            } else adminPassword = "admin123";
        
     
     
        
    }
    
    
    
}
