
package EditTables;

import Notifications.LocationError;
import Notifications.PleaseFillIn;
import Notifications.numberError;
import java.awt.Color;
import AMS.*;
import javax.swing.table.DefaultTableModel;
import Notifications.WarnData;

public class EditFlightTable extends javax.swing.JFrame {
    Main_GUI mainGUI;
 
   
    public EditFlightTable(Main_GUI mainGUI) {
        initComponents();
        this.mainGUI = mainGUI;
         loadAirplanes();
         loadAirports();
        comboAirplane.addActionListener(e -> showPlaneCapacity());
        WarnData.DataStorage();
        DefaultTableModel model = (DefaultTableModel) mainGUI.flightsTable.getModel();
        comboAirplane.setSelectedItem(model.getValueAt(mainGUI.flightsTable.getSelectedRow(), 1).toString());
        comboOrigin.setSelectedItem(model.getValueAt(mainGUI.flightsTable.getSelectedRow(), 2).toString());
        comboDestination.setSelectedItem(model.getValueAt(mainGUI.flightsTable.getSelectedRow(), 3).toString());
        dYear.setText(WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][0]);
        dMonth.setText(WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][1]);
        dDay.setText(WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][2]);
        dHour.setText(WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][3]);
        dMin.setText(WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][4]);
        dSec.setText(WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][5]);
        aYear.setText(WarnData.atime[mainGUI.flightsTable.getSelectedRow()][0]);
        aMonth.setText(WarnData.atime[mainGUI.flightsTable.getSelectedRow()][1]);
        aDay.setText(WarnData.atime[mainGUI.flightsTable.getSelectedRow()][2]);
        aHour.setText(WarnData.atime[mainGUI.flightsTable.getSelectedRow()][3]);
        aMin.setText(WarnData.atime[mainGUI.flightsTable.getSelectedRow()][4]);
        aSec.setText(WarnData.atime[mainGUI.flightsTable.getSelectedRow()][5]);
        String depVal = model.getValueAt(mainGUI.flightsTable.getSelectedRow(), 4).toString();
        String arrVal = model.getValueAt(mainGUI.flightsTable.getSelectedRow(), 5).toString();
        String depap = depVal.substring(depVal.length()-2).toUpperCase();
        String arrap = arrVal.substring(arrVal.length()-2).toUpperCase();
        a.setSelectedItem(depap);
        p.setSelectedItem(arrap);
        System.out.println(depap);
        System.out.println(arrap);
        
        
    }

    
            private void loadAirplanes() {
    comboAirplane.removeAllItems();
    if (mainGUI.flightsTable != null) {
        for (int i = 0; i < mainGUI.planeTable.getRowCount(); i++) {
            String model = mainGUI.planeTable.getValueAt(i, 3).toString(); 
            comboAirplane.addItem(model);
        }
    }
}

private void loadAirports() {
    comboOrigin.removeAllItems();
    comboDestination.removeAllItems();
    if (mainGUI.airportTable != null) {
        for (int i = 0; i < mainGUI.airportTable.getRowCount(); i++) {
            String city = mainGUI.airportTable.getValueAt(i, 1).toString(); 
            comboDestination.addItem(city);
            comboOrigin.addItem(city);
            
        }
    }
}

private void showPlaneCapacity() {
    String selectedModel = (String) comboAirplane.getSelectedItem();
    if (selectedModel != null && mainGUI.planeTable != null) {
        for (int i = 0; i < mainGUI.planeTable.getRowCount(); i++) {
            String model = mainGUI.planeTable.getValueAt(i, 3).toString();
            if (model.equals(selectedModel)) {
                String economy = mainGUI.planeTable.getValueAt(i, 1).toString(); // economy column
                String business = mainGUI.planeTable.getValueAt(i, 2).toString(); // business column
                ecoCap.setText(economy);
                busCap.setText(business);
                break;
            }
        }
    }
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.JPanel jPanel1 = new javax.swing.JPanel();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        javax.swing.JLabel jLabel3 = new javax.swing.JLabel();
        comboAirplane = new javax.swing.JComboBox<>();
        javax.swing.JLabel jLabel4 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel6 = new javax.swing.JLabel();
        comboOrigin = new javax.swing.JComboBox<>();
        comboDestination = new javax.swing.JComboBox<>();
        javax.swing.JLabel jLabel7 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel8 = new javax.swing.JLabel();
        dYear = new javax.swing.JTextField();
        dMonth = new javax.swing.JTextField();
        dDay = new javax.swing.JTextField();
        dHour = new javax.swing.JTextField();
        dMin = new javax.swing.JTextField();
        dSec = new javax.swing.JTextField();
        aYear = new javax.swing.JTextField();
        aMonth = new javax.swing.JTextField();
        aDay = new javax.swing.JTextField();
        aHour = new javax.swing.JTextField();
        aMin = new javax.swing.JTextField();
        aSec = new javax.swing.JTextField();
        javax.swing.JLabel jLabel9 = new javax.swing.JLabel();
        javax.swing.JLabel bus = new javax.swing.JLabel();
        ecoCap = new javax.swing.JLabel();
        busCap = new javax.swing.JLabel();
        a = new javax.swing.JComboBox<>();
        p = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(0, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 102, 0), 2));

        jPanel2.setBackground(new java.awt.Color(204, 102, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Edit Flight");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                .addContainerGap())
        );

        submit.setBackground(new java.awt.Color(204, 102, 0));
        submit.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        submit.setText("Sumbit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        cancel.setBackground(new java.awt.Color(204, 102, 0));
        cancel.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Airplane:");

        comboAirplane.setBackground(new java.awt.Color(204, 102, 0));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Origin:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Destination:");

        comboOrigin.setBackground(new java.awt.Color(204, 102, 0));

        comboDestination.setBackground(new java.awt.Color(204, 102, 0));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Departure:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Arrival:");

        dYear.setText("Year");
        dYear.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dYearFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                dYearFocusLost(evt);
            }
        });
        dYear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dYearMouseClicked(evt);
            }
        });
        dYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dYearActionPerformed(evt);
            }
        });

        dMonth.setText("Month");
        dMonth.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dMonthFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                dMonthFocusLost(evt);
            }
        });
        dMonth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dMonthMouseClicked(evt);
            }
        });

        dDay.setText("Day");
        dDay.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dDayFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                dDayFocusLost(evt);
            }
        });
        dDay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dDayMouseClicked(evt);
            }
        });

        dHour.setText("Hour");
        dHour.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dHourFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                dHourFocusLost(evt);
            }
        });
        dHour.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dHourMouseClicked(evt);
            }
        });

        dMin.setText("Minutes");
        dMin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dMinFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                dMinFocusLost(evt);
            }
        });
        dMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dMinMouseClicked(evt);
            }
        });
        dMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dMinActionPerformed(evt);
            }
        });

        dSec.setText("Seconds");
        dSec.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dSecFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                dSecFocusLost(evt);
            }
        });
        dSec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dSecMouseClicked(evt);
            }
        });
        dSec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dSecActionPerformed(evt);
            }
        });

        aYear.setText("Year");
        aYear.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                aYearFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                aYearFocusLost(evt);
            }
        });
        aYear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aYearMouseClicked(evt);
            }
        });

        aMonth.setText("Month");
        aMonth.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                aMonthFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                aMonthFocusLost(evt);
            }
        });
        aMonth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aMonthMouseClicked(evt);
            }
        });

        aDay.setText("Day");
        aDay.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                aDayFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                aDayFocusLost(evt);
            }
        });
        aDay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aDayMouseClicked(evt);
            }
        });

        aHour.setText("Hour");
        aHour.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                aHourFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                aHourFocusLost(evt);
            }
        });
        aHour.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aHourMouseClicked(evt);
            }
        });

        aMin.setText("Minute");
        aMin.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                aMinFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                aMinFocusLost(evt);
            }
        });
        aMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aMinMouseClicked(evt);
            }
        });

        aSec.setText("Seconds");
        aSec.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                aSecFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                aSecFocusLost(evt);
            }
        });
        aSec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aSecMouseClicked(evt);
            }
        });
        aSec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aSecActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Economy:");

        bus.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        bus.setForeground(new java.awt.Color(255, 255, 255));
        bus.setText("Business:");

        ecoCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        ecoCap.setForeground(new java.awt.Color(255, 255, 255));
        ecoCap.setText("e");

        busCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        busCap.setForeground(new java.awt.Color(255, 255, 255));
        busCap.setText("b");

        a.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        a.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AM", "PM" }));

        p.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        p.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AM", "PM" }));
        p.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(aYear, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(aMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(aDay, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(aHour, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(aMin, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(aSec, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p, 0, 59, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(dYear, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dDay, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dHour, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dMin, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dSec, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(a, 0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cancel, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(submit, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(comboAirplane, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(comboOrigin, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(comboDestination, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ecoCap, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15)
                                .addComponent(bus)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(busCap, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(23, 23, 23))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(comboAirplane, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(bus)
                    .addComponent(ecoCap)
                    .addComponent(busCap))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6)
                    .addComponent(comboOrigin, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboDestination, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(a, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(dYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dHour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dSec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(aYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aHour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aSec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(p, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancel)
                    .addComponent(submit))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
        String airplane = "";
        String origin = "";
        String destination = "";

        if (comboAirplane.getSelectedIndex() != -1 && comboOrigin.getSelectedIndex() != -1 && comboDestination.getSelectedIndex() != -1) {
            airplane = comboAirplane.getSelectedItem().toString();
            origin = comboOrigin.getSelectedItem().toString();
            destination = comboDestination.getSelectedItem().toString();
        }

        String dep = dYear.getText() + "-" + dMonth.getText() + "-" +
        dDay.getText() + "-" + dHour.getText() + ":" +
        dMin.getText() + ":" + dSec.getText() + " " + a.getSelectedItem().toString().toLowerCase();

        String arr = aYear.getText() + "-" + aMonth.getText() + "-" +
        aDay.getText() + "-" + aHour.getText() + ":" +
        aMin.getText() + ":" + aSec.getText() + " " + p.getSelectedItem().toString().toLowerCase();

        String status = "Estimated";
        String economy = ecoCap.getText();
        String business = busCap.getText();

        if (comboAirplane.getSelectedIndex() == -1 || comboOrigin.getSelectedIndex() == -1 || comboDestination.getSelectedIndex() == -1 ||
            dYear.getText().isEmpty() || dMonth.getText().isEmpty() || dDay.getText().isEmpty() || dHour.getText().isEmpty() || dMin.getText().isEmpty() || dSec.getText().isEmpty() ||
            aYear.getText().isEmpty() || aMonth.getText().isEmpty() || aDay.getText().isEmpty() || aHour.getText().isEmpty() || aMin.getText().isEmpty() || aSec.getText().isEmpty() ||
            dYear.getText().equals("Year") || dMonth.getText().equals("Month") || dDay.getText().equals("Day") || dHour.getText().equals("Hour") || dMin.getText().equals("Minute") || dSec.getText().equals("Second") ||
            aYear.getText().equals("Year") || aMonth.getText().equals("Month") || aDay.getText().equals("Day") || aHour.getText().equals("Hour") || aMin.getText().equals("Minute") || aSec.getText().equals("Second")) {
            PleaseFillIn pfi = new PleaseFillIn();
            pfi.setVisible(true);
            pfi.pack();
        } else if (comboOrigin.getSelectedIndex() == comboDestination.getSelectedIndex()) {
        LocationError le = new LocationError();
        le.pack();
        le.setVisible(true);
    } else if (!Check.isNumber(dYear.getText()) || !Check.isNumber(dMonth.getText()) || !Check.isNumber(dDay.getText()) || !Check.isNumber(dHour.getText()) || !Check.isNumber(dMin.getText()) || !Check.isNumber(dSec.getText()) ||
            !Check.isNumber(aYear.getText()) || !Check.isNumber(aMonth.getText()) || !Check.isNumber(aDay.getText()) || !Check.isNumber(aHour.getText()) || !Check.isNumber(aMin.getText()) || !Check.isNumber(aSec.getText())) {
            numberError ne = new numberError();
            ne.pack();
            ne.setVisible(true);
            if (!Check.isNumber(dYear.getText())) {
                dYear.setText("");
            }
            if (!Check.isNumber(dMonth.getText())) {
                dMonth.setText("");
            }
            if (!Check.isNumber(dDay.getText())) {
                dDay.setText("");
            }
            if (!Check.isNumber(dHour.getText())) {
                dHour.setText("");
            }
            if (!Check.isNumber(dMin.getText())) {
                dMin.setText("");
            }
            if (!Check.isNumber(dSec.getText())) {
                dSec.setText("");
            }
            if (!Check.isNumber(aYear.getText())) {
                aYear.setText("");
            }
            if (!Check.isNumber(aMonth.getText())) {
                aMonth.setText("");
            }
            if (!Check.isNumber(aDay.getText())) {
                aDay.setText("");
            }
            if (!Check.isNumber(aHour.getText())) {
                aHour.setText("");
            }
            if (!Check.isNumber(aMin.getText())) {
                aMin.setText("");
            }
            if (!Check.isNumber(aSec.getText())) {
                aSec.setText("");
            }
        } else {

            if (mainGUI.flightsTable != null) {
                DefaultTableModel model = (DefaultTableModel) mainGUI.flightsTable.getModel();
                    model.setValueAt(airplane, mainGUI.flightsTable.getSelectedRow(), 1);
                    model.setValueAt(origin, mainGUI.flightsTable.getSelectedRow(), 2);
                    model.setValueAt(destination, mainGUI.flightsTable.getSelectedRow(), 3);
                    model.setValueAt(dep, mainGUI.flightsTable.getSelectedRow(), 4);
                    model.setValueAt(arr, mainGUI.flightsTable.getSelectedRow(), 5);
                    model.setValueAt(status, mainGUI.flightsTable.getSelectedRow(), 6);
                    model.setValueAt(economy, mainGUI.flightsTable.getSelectedRow(), 7);
                    model.setValueAt(business, mainGUI.flightsTable.getSelectedRow(), 8);
            }
            
            WarnData.DataStorage();
            WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][0] = dYear.getText();
            WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][1] = dMonth.getText();
            WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][2] = dDay.getText();
            WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][3] = dHour.getText();
            WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][4] = dMin.getText();
            WarnData.dtime[mainGUI.flightsTable.getSelectedRow()][5] = dSec.getText();
            
            WarnData.atime[mainGUI.flightsTable.getSelectedRow()][0] = aYear.getText();
            WarnData.atime[mainGUI.flightsTable.getSelectedRow()][1] = aMonth.getText();
            WarnData.atime[mainGUI.flightsTable.getSelectedRow()][2] = aDay.getText();
            WarnData.atime[mainGUI.flightsTable.getSelectedRow()][3] = aHour.getText();
            WarnData.atime[mainGUI.flightsTable.getSelectedRow()][4] = aMin.getText();
            WarnData.atime[mainGUI.flightsTable.getSelectedRow()][5] = aSec.getText();

            this.dispose();

        }
    }//GEN-LAST:event_submitActionPerformed

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        this.dispose();
    }//GEN-LAST:event_cancelActionPerformed

    private void dYearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dYearMouseClicked
        dYear.setText("");
        dYear.setForeground(Color.BLACK);
    }//GEN-LAST:event_dYearMouseClicked

    private void dYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dYearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dYearActionPerformed

    private void dMonthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dMonthMouseClicked
        dMonth.setText("");
        dMonth.setForeground(Color.BLACK);
    }//GEN-LAST:event_dMonthMouseClicked

    private void dDayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dDayMouseClicked
        dDay.setText("");
        dDay.setForeground(Color.BLACK);
    }//GEN-LAST:event_dDayMouseClicked

    private void dHourMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dHourMouseClicked
        dHour.setText("");
        dHour.setForeground(Color.BLACK);
    }//GEN-LAST:event_dHourMouseClicked

    private void dMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dMinMouseClicked
        dMin.setText("");
        dMin.setForeground(Color.BLACK);
    }//GEN-LAST:event_dMinMouseClicked

    private void dMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dMinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dMinActionPerformed

    private void dSecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dSecMouseClicked
        dSec.setText("");
        dSec.setForeground(Color.BLACK);
    }//GEN-LAST:event_dSecMouseClicked

    private void dSecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dSecActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dSecActionPerformed

    private void aYearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aYearMouseClicked
        aYear.setText("");
        aYear.setForeground(Color.BLACK);
    }//GEN-LAST:event_aYearMouseClicked

    private void aMonthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aMonthMouseClicked
        aMonth.setText("");
        aMonth.setForeground(Color.BLACK);
    }//GEN-LAST:event_aMonthMouseClicked

    private void aDayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aDayMouseClicked
        aDay.setText("");
        aDay.setForeground(Color.BLACK);
    }//GEN-LAST:event_aDayMouseClicked

    private void aHourMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aHourMouseClicked
        aHour.setText("");
        aHour.setForeground(Color.BLACK);
    }//GEN-LAST:event_aHourMouseClicked

    private void aMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aMinMouseClicked
        aMin.setText("");
        aMin.setForeground(Color.BLACK);
    }//GEN-LAST:event_aMinMouseClicked

    private void aSecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aSecMouseClicked
        aSec.setText("");
        aSec.setForeground(Color.BLACK);
    }//GEN-LAST:event_aSecMouseClicked

    private void aSecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aSecActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aSecActionPerformed

    private void dYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dYearFocusGained
      if (dYear.getText().equals("Year")){
        dYear.setText("");
        dYear.setForeground(Color.BLACK);
      }
    }//GEN-LAST:event_dYearFocusGained

    private void dMonthFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dMonthFocusGained
        if (dMonth.getText().equals("Month")){
        dMonth.setText("");
        dMonth.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_dMonthFocusGained

    private void dDayFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dDayFocusGained
       if (dDay.getText().equals("Day")){
        dDay.setText("");
        dDay.setForeground(Color.BLACK);
       }
    }//GEN-LAST:event_dDayFocusGained

    private void dHourFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dHourFocusGained
        if (dHour.getText().equals("Hour")){
        dHour.setText("");
        dHour.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_dHourFocusGained

    private void dMinFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dMinFocusGained
        if (dMin.getText().equals("Minutes")){
        dMin.setText("");
        dMin.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_dMinFocusGained

    private void dSecFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dSecFocusGained
        if (dSec.getText().equals("Seconds")){
        dSec.setText("");
       dSec.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_dSecFocusGained

    private void dYearFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dYearFocusLost
        if(dYear.getText().isEmpty()) {
        dYear.setText("Year");
       dYear.setForeground(Color.GRAY);
      }
    }//GEN-LAST:event_dYearFocusLost

    private void dMonthFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dMonthFocusLost
        if(dMonth.getText().isEmpty()) {
        dMonth.setText("Month");
        dMonth.setForeground(Color.GRAY);
       }
    }//GEN-LAST:event_dMonthFocusLost

    private void dDayFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dDayFocusLost
        if(dDay.getText().isEmpty()) {
        dDay.setText("Day");
        dDay.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_dDayFocusLost

    private void dHourFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dHourFocusLost
        if(dHour.getText().isEmpty()) {
        dHour.setText("Hour");
        dHour.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_dHourFocusLost

    private void dMinFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dMinFocusLost
        if(dMin.getText().isEmpty()) {
        dMin.setText("Minutes");
        dMin.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_dMinFocusLost

    private void dSecFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dSecFocusLost
        if(dSec.getText().isEmpty()) {
        dSec.setText("Seconds");
        dSec.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_dSecFocusLost

    private void aYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aYearFocusGained
        if (aYear.getText().equals("Year")){
        aYear.setText("");
        aYear.setForeground(Color.BLACK);
       }
    }//GEN-LAST:event_aYearFocusGained

    private void aMonthFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aMonthFocusGained
        if (aMonth.getText().equals("Month")){
        aMonth.setText("");
        aMonth.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_aMonthFocusGained

    private void aDayFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aDayFocusGained
        if (aDay.getText().equals("Day")){
        aDay.setText("");
        aDay.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_aDayFocusGained

    private void aHourFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aHourFocusGained
        if (aHour.getText().equals("Hour")){
        aHour.setText("");
        aHour.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_aHourFocusGained

    private void aMinFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aMinFocusGained
        if (aMin.getText().equals("Minutes")){
        aMin.setText("");
        aMin.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_aMinFocusGained

    private void aSecFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aSecFocusGained
        if (aSec.getText().equals("Seconds")){
        aSec.setText("");
        aSec.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_aSecFocusGained

    private void aYearFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aYearFocusLost
        if(aYear.getText().isEmpty()) {
        aYear.setText("Year");
        aYear.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_aYearFocusLost

    private void aMonthFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aMonthFocusLost
        if(aMonth.getText().isEmpty()) {
        aMonth.setText("Month");
        aMonth.setForeground(Color.GRAY);
       }
    }//GEN-LAST:event_aMonthFocusLost

    private void aDayFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aDayFocusLost
        if(aDay.getText().isEmpty()) {
        aDay.setText("Day");
        aDay.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_aDayFocusLost

    private void aHourFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aHourFocusLost
        if(aHour.getText().isEmpty()) {
        aHour.setText("Hour");
        aHour.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_aHourFocusLost

    private void aMinFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aMinFocusLost
        if(aMin.getText().isEmpty()) {
        aMin.setText("Minutes");
        aMin.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_aMinFocusLost

    private void aSecFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_aSecFocusLost
        if(aSec.getText().isEmpty()) {
        aSec.setText("Seconds");
        aSec.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_aSecFocusLost

    private void pActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditFlightTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditFlightTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditFlightTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditFlightTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> a;
    private javax.swing.JTextField aDay;
    private javax.swing.JTextField aHour;
    private javax.swing.JTextField aMin;
    private javax.swing.JTextField aMonth;
    private javax.swing.JTextField aSec;
    private javax.swing.JTextField aYear;
    private javax.swing.JLabel busCap;
    private javax.swing.JButton cancel;
    private javax.swing.JComboBox<String> comboAirplane;
    private javax.swing.JComboBox<String> comboDestination;
    private javax.swing.JComboBox<String> comboOrigin;
    private javax.swing.JTextField dDay;
    private javax.swing.JTextField dHour;
    private javax.swing.JTextField dMin;
    private javax.swing.JTextField dMonth;
    private javax.swing.JTextField dSec;
    private javax.swing.JTextField dYear;
    private javax.swing.JLabel ecoCap;
    private javax.swing.JComboBox<String> p;
    private javax.swing.JButton submit;
    // End of variables declaration//GEN-END:variables
}
