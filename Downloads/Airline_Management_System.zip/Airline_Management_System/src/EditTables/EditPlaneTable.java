
package EditTables;
import AMS.Main_GUI;
import Notifications.PleaseFillIn;
import Notifications.numberError;
import javax.swing.table.DefaultTableModel;

public class EditPlaneTable extends javax.swing.JFrame {
            Main_GUI mainGUI;
   
    public EditPlaneTable(Main_GUI mainGUI) {
        initComponents();
        this.mainGUI = mainGUI;
        DefaultTableModel model = (DefaultTableModel) mainGUI.planeTable.getModel();
        economy.setText(model.getValueAt(mainGUI.planeTable.getSelectedRow(), 1).toString());
        business.setText(model.getValueAt(mainGUI.planeTable.getSelectedRow(), 2).toString());
        modelPLane.setText(model.getValueAt(mainGUI.planeTable.getSelectedRow(), 3).toString());
    }

    boolean isNumber(String text) {
    try {
        Integer.parseInt(text); 
        return true;             
    } catch (NumberFormatException e) {
        return false;           
    }
}
    
       private void refreshIDs(javax.swing.JTable table) {
    javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) table.getModel();
    for (int i = 0; i < model.getRowCount(); i++) {
        model.setValueAt(i, i, 0); 
    }
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        submit2 = new javax.swing.JButton();
        javax.swing.JPanel jPanel1 = new javax.swing.JPanel();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        javax.swing.JLabel jLabel2 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel3 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel4 = new javax.swing.JLabel();
        economy = new javax.swing.JTextField();
        business = new javax.swing.JTextField();
        modelPLane = new javax.swing.JTextField();
        cancel = new javax.swing.JButton();
        submit3 = new javax.swing.JButton();

        submit2.setBackground(new java.awt.Color(204, 51, 0));
        submit2.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        submit2.setText("Delete");
        submit2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submit2ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(0, 51, 51));

        jPanel2.setBackground(new java.awt.Color(204, 102, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Edit Plane");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                .addContainerGap())
        );

        submit.setBackground(new java.awt.Color(204, 102, 0));
        submit.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        submit.setText("Sumbit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Economy Capacity:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Business Capacity:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Model:");

        economy.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                economyMouseClicked(evt);
            }
        });
        economy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                economyActionPerformed(evt);
            }
        });

        business.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                businessMouseClicked(evt);
            }
        });
        business.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                businessActionPerformed(evt);
            }
        });

        modelPLane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                modelPLaneMouseClicked(evt);
            }
        });

        cancel.setBackground(new java.awt.Color(204, 102, 0));
        cancel.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });

        submit3.setBackground(new java.awt.Color(204, 51, 0));
        submit3.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        submit3.setText("Delete");
        submit3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submit3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(economy, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(business, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(modelPLane, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(cancel, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(submit, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(submit3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(economy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(business, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(modelPLane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submit)
                    .addComponent(cancel))
                .addGap(18, 18, 18)
                .addComponent(submit3)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
     DefaultTableModel model = (DefaultTableModel) mainGUI.planeTable.getModel();
     if (!isNumber(economy.getText()) || !isNumber(business.getText())) {
         numberError er = new numberError();
            er.pack();
            er.setVisible(true);
            if (!isNumber(economy.getText())) {
            economy.setText("");
            }
            if (!isNumber(business.getText())) {
            business.setText("");
            }
     } else if (!economy.getText().isEmpty() && !business.getText().isEmpty() && !modelPLane.getText().isEmpty()) {
        model.setValueAt(economy.getText(), mainGUI.planeTable.getSelectedRow(), 1);
        model.setValueAt(business.getText(), mainGUI.planeTable.getSelectedRow(), 2);
        model.setValueAt(modelPLane.getText(), mainGUI.planeTable.getSelectedRow(), 3);
        this.dispose();
     } else {
          PleaseFillIn pfi = new PleaseFillIn();
          pfi.setVisible(true);
          pfi.pack();
     }
        


    }//GEN-LAST:event_submitActionPerformed

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        this.dispose();
    }//GEN-LAST:event_cancelActionPerformed

    private void economyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_economyMouseClicked
        economy.setText("");
    }//GEN-LAST:event_economyMouseClicked

    private void businessMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_businessMouseClicked
       business.setText("");
    }//GEN-LAST:event_businessMouseClicked

    private void modelPLaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modelPLaneMouseClicked
       modelPLane.setText("");
    }//GEN-LAST:event_modelPLaneMouseClicked

    private void economyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_economyActionPerformed
        if (!isNumber(economy.getText())) {
            numberError er = new numberError();
            er.pack();
            er.setVisible(true);
            economy.setText("");
        }
    }//GEN-LAST:event_economyActionPerformed

    private void businessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_businessActionPerformed
        if (!isNumber(business.getText())) {
            numberError er = new numberError();
            er.pack();
            er.setVisible(true);
            business.setText("");
        }
    }//GEN-LAST:event_businessActionPerformed

    private void submit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submit2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_submit2ActionPerformed

    private void submit3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submit3ActionPerformed
        DefaultTableModel model = (DefaultTableModel) mainGUI.planeTable.getModel();
        model.removeRow(mainGUI.planeTable.getSelectedRow());
         
        this.dispose();
    }//GEN-LAST:event_submit3ActionPerformed

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField business;
    private javax.swing.JButton cancel;
    private javax.swing.JTextField economy;
    private javax.swing.JTextField modelPLane;
    private javax.swing.JButton submit;
    private javax.swing.JButton submit2;
    private javax.swing.JButton submit3;
    // End of variables declaration//GEN-END:variables
}
