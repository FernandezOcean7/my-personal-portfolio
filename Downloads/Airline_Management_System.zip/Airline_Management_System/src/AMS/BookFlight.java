package AMS;

import Notifications.InvalidDetail;
import Notifications.PleaseFillIn;
import Notifications.alreadyBooked;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import Notifications.*;

public class BookFlight extends javax.swing.JFrame {
private String flightID;
private Main_GUI mainGUI;
private static String[] passIDs;
 
    
    public BookFlight(Main_GUI mainGUI,  String flightID) {
        initComponents();
        this.mainGUI = mainGUI;
        this.flightID = flightID;
        passIDs = new String[mainGUI.passengerTable.getRowCount()];
        loadPassenger();
        comboPassenger.setSelectedIndex(-1);
        comboTicker.setSelectedIndex(-1);
        comboPassenger.addActionListener(e -> showPassengerDetail());
    }
    
           private void loadPassenger() {
    if (mainGUI.flightsTable != null) {
        for (int i = 0; i < mainGUI.passengerTable.getRowCount(); i++) {
            String model = mainGUI.passengerTable.getValueAt(i, 1).toString();
            String id = mainGUI.passengerTable.getValueAt(i, 0).toString();
            comboPassenger.addItem(id + "-" + model);
            passIDs[i] = id;
        }
    }
}
           
           private void showPassengerDetail() {
    int selectedIndex = comboPassenger.getSelectedIndex();
    if (selectedIndex != -1 && mainGUI.passengerTable != null) {
        String selectedID = passIDs[selectedIndex];
        
        for (int i = 0; i <mainGUI.passengerTable.getRowCount(); i++) {
            String tableID = mainGUI.passengerTable.getValueAt(i,0).toString();
            
            if(tableID.equals(selectedID)){
                String phone = mainGUI.passengerTable.getValueAt(selectedIndex, 2).toString(); 
                String email = mainGUI.passengerTable.getValueAt(selectedIndex, 3).toString(); 
                pn.setText(phone);
                ea.setText(email);     
            }
        }
    }
}
           
           
           


   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.JPanel jPanel1 = new javax.swing.JPanel();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        javax.swing.JLabel jLabel3 = new javax.swing.JLabel();
        cancel = new javax.swing.JButton();
        javax.swing.JLabel jLabel4 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel5 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel6 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel7 = new javax.swing.JLabel();
        comboTicker = new javax.swing.JComboBox<>();
        seatField = new javax.swing.JTextField();
        ecoCap = new javax.swing.JLabel();
        busCap = new javax.swing.JLabel();
        pn = new javax.swing.JLabel();
        ea = new javax.swing.JLabel();
        comboPassenger = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(0, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 102, 0), 2));

        jPanel2.setBackground(new java.awt.Color(204, 102, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Book Flight");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                .addContainerGap())
        );

        submit.setBackground(new java.awt.Color(204, 102, 0));
        submit.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        submit.setText("Sumbit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Passenger:");

        cancel.setBackground(new java.awt.Color(204, 102, 0));
        cancel.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Phone #:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Ticket Type:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Email:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Seat:");

        comboTicker.setBackground(new java.awt.Color(204, 102, 0));
        comboTicker.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Economy", "Business" }));
        comboTicker.setSelectedIndex(-1);
        comboTicker.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTickerActionPerformed(evt);
            }
        });

        ecoCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        ecoCap.setForeground(new java.awt.Color(255, 255, 255));

        busCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        busCap.setForeground(new java.awt.Color(255, 255, 255));

        pn.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        pn.setForeground(new java.awt.Color(255, 255, 255));

        ea.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        ea.setForeground(new java.awt.Color(255, 255, 255));

        comboPassenger.setBackground(new java.awt.Color(204, 102, 0));
        comboPassenger.setSelectedIndex(-1);
        comboPassenger.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboPassengerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(comboTicker, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap(104, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(seatField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pn, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ea, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(41, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(comboPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cancel, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(submit, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(ecoCap, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(86, 86, 86)
                    .addComponent(busCap, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(comboPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(pn))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(ea))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(comboTicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(seatField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancel)
                    .addComponent(submit))
                .addContainerGap(33, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(202, 202, 202)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ecoCap)
                        .addComponent(busCap))
                    .addContainerGap(203, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
       
        String tel = pn.getText();
        String email = ea.getText();
        String seatNum = seatField.getText();
        boolean seatExist = false;
        
        for (int i = 0; i < WarnData.registerSeatFlight(flightID).length; i++) {
            String currentSeat = WarnData.registerSeatFlight(flightID)[i];
            System.out.println(currentSeat);
            if (seatNum.equals(currentSeat)) {
                seatExist = true;
                break;
            }
        }
       
        
       
        if (comboPassenger.getSelectedIndex() == -1 || comboTicker.getSelectedIndex() == -1 || seatNum.isEmpty()) {
            PleaseFillIn pfi = new PleaseFillIn();
            pfi.pack();
            pfi.setVisible(true);
        } else if (!(seatNum.equals("1A") || seatNum.equals("2A") || seatNum.equals("3A") || seatNum.equals("4A") || seatNum.equals("5A") || 
                   seatNum.equals("6A") || seatNum.equals("7A") || seatNum.equals("8A") || seatNum.equals("9A") || seatNum.equals("10A")     ||
                   seatNum.equals("11A") || seatNum.equals("12A") || seatNum.equals("13A") || seatNum.equals("14A") || seatNum.equals("15A") || 
                   seatNum.equals("16A") || seatNum.equals("17A") || seatNum.equals("18A") || seatNum.equals("19A") || seatNum.equals("20A") ||
                   seatNum.equals("1B") || seatNum.equals("2B") || seatNum.equals("3B") || seatNum.equals("4B") || seatNum.equals("5B") || 
                   seatNum.equals("6B") || seatNum.equals("7B") || seatNum.equals("8B") || seatNum.equals("9B") || seatNum.equals("10B")     ||
                   seatNum.equals("11B") || seatNum.equals("12B") || seatNum.equals("13B") || seatNum.equals("14B") || seatNum.equals("15B") || 
                   seatNum.equals("16B") || seatNum.equals("17B") || seatNum.equals("18B") || seatNum.equals("19B") || seatNum.equals("20B") ||
                   seatNum.equals("1C") || seatNum.equals("2C") || seatNum.equals("3C") || seatNum.equals("4C") || seatNum.equals("5C") || 
                   seatNum.equals("6C") || seatNum.equals("7C") || seatNum.equals("8C") || seatNum.equals("9C") || seatNum.equals("10C")     ||
                   seatNum.equals("11C") || seatNum.equals("12C") || seatNum.equals("13C") || seatNum.equals("14C") || seatNum.equals("15C") || 
                   seatNum.equals("16C") || seatNum.equals("17C") || seatNum.equals("18C") || seatNum.equals("19C") || seatNum.equals("20C") ||
                   seatNum.equals("1D") || seatNum.equals("2D") || seatNum.equals("3D") || seatNum.equals("4D") || seatNum.equals("5D") || 
                   seatNum.equals("6D") || seatNum.equals("7D") || seatNum.equals("8D") || seatNum.equals("9D") || seatNum.equals("10D")     ||
                   seatNum.equals("11D") || seatNum.equals("12D") || seatNum.equals("13D") || seatNum.equals("14D") || seatNum.equals("15D") || 
                   seatNum.equals("16D") || seatNum.equals("17D") || seatNum.equals("18D") || seatNum.equals("19D") || seatNum.equals("20D") ||
                   seatNum.equals("1E") || seatNum.equals("2E") || seatNum.equals("3E") || seatNum.equals("4E") || seatNum.equals("5E") || 
                   seatNum.equals("6E") || seatNum.equals("7E") || seatNum.equals("8E") || seatNum.equals("9E") || seatNum.equals("10E")     ||
                   seatNum.equals("11E") || seatNum.equals("12E") || seatNum.equals("13E") || seatNum.equals("14E") || seatNum.equals("15E") || 
                   seatNum.equals("16E") || seatNum.equals("17E") || seatNum.equals("18E") || seatNum.equals("19E") || seatNum.equals("20E") ||
                   seatNum.equals("1F") || seatNum.equals("2F") || seatNum.equals("3F") || seatNum.equals("4F") || seatNum.equals("5F") || 
                   seatNum.equals("6F") || seatNum.equals("7F") || seatNum.equals("8F") || seatNum.equals("9F") || seatNum.equals("10F")     ||
                   seatNum.equals("11F") || seatNum.equals("12F") || seatNum.equals("13F") || seatNum.equals("14F") || seatNum.equals("15F") || 
                   seatNum.equals("16F") || seatNum.equals("17F") || seatNum.equals("18F") || seatNum.equals("19F") || seatNum.equals("20F"))) {            
            InvalidDetail ne = new InvalidDetail();
            ne.pack();
            ne.setVisible(true);                       
        } else if (seatExist) {
                    SeatAlreadyExist sae = new SeatAlreadyExist();
                    sae.setVisible(true);
                    sae.pack();                    
        } else {
         String name = comboPassenger.getSelectedItem().toString();
         String ticket = comboTicker.getSelectedItem().toString();
         String id = passIDs[comboPassenger.getSelectedIndex()];
                 
         
                javax.swing.table.DefaultTableModel model = Notifications.WarnData.getPassengerModelForFlight(flightID);
                
          for (int i = 0; i < WarnData.registerSeatFlight(flightID).length; i++) {
              if (WarnData.registerSeatFlight(flightID)[i] != null && !WarnData.registerSeatFlight(flightID)[i].isEmpty()) {
                  continue;
              } else {
                  WarnData.registerSeatFlight(flightID)[i] = seatNum;
                  break;
              }
          }
                                                                      
          boolean alreadyBooked = false;
          for (int i = 0; i < model.getRowCount(); i++) {
              String existingId = model.getValueAt(i, 0).toString(); 
              if (existingId.equals(id)) {
                  alreadyBooked = true;
                  break;
              }
          }

        
          if (alreadyBooked) {
              alreadyBooked ab = new alreadyBooked();
              ab.setVisible(true);
              ab.pack();
              return; 
          }
          
          String ref = WarnData.generateReference();
          
          for (int i = 0; i < 100; i++){
              String refId = WarnData.ref[i];
              if (ref.equals(refId)){
                  ref = WarnData.generateReference();
                  break;
              }
          }
          
          
          for (int i = 0; i < 100; i++) {
             if (WarnData.ref[i] != null && WarnData.ref[i].isEmpty()){
                 continue;
             } else {
                 WarnData.ref[i] = ref;
                 break;
             }
          }
          String fid = mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 0).toString();
          String from = mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 2).toString();
          String to = mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 3).toString();
          String de = mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 4).toString();
          String ar = mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 5).toString();
          String ticketPrice = "";
          if (comboTicker.getSelectedIndex() == 0) {
              ticketPrice = mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 7).toString();
          } else if (comboTicker.getSelectedIndex() == 1) {
              ticketPrice = mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 8).toString();
          }
          
          model.addRow(new Object[]{id, name, tel, email, ticket, seatNum, ref});
          Reciept r = new Reciept(mainGUI);
          r.name.setText(name);
          r.reference.setText(" " + ref);
          r.flight.setText(fid);
          r.from.setText(from);
          r.to.setText(to);
          r.depart.setText(de);
          r.arrive.setText(" " + ar);
          r.seat.setText(seatNum);
          r.ticketType.setText(comboTicker.getSelectedItem().toString());
          r.ticketPrice.setText(ticketPrice);
          r.totalPaid.setText(" " + ticketPrice);
          r.setVisible(true);
          r.pack();          
          this.dispose();
                }
      
   
    }//GEN-LAST:event_submitActionPerformed
    
    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
       FlightOption fo = new FlightOption(mainGUI);
       fo.setVisible(true);
       fo.pack();
        this.dispose();
    }//GEN-LAST:event_cancelActionPerformed

    private void comboTickerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTickerActionPerformed
      
    }//GEN-LAST:event_comboTickerActionPerformed

    private void comboPassengerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboPassengerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboPassengerActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BookFlight.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BookFlight.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BookFlight.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BookFlight.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel busCap;
    private javax.swing.JButton cancel;
    public javax.swing.JComboBox<String> comboPassenger;
    public javax.swing.JComboBox<String> comboTicker;
    private javax.swing.JLabel ea;
    private javax.swing.JLabel ecoCap;
    private javax.swing.JLabel pn;
    private javax.swing.JTextField seatField;
    private javax.swing.JButton submit;
    // End of variables declaration//GEN-END:variables
}
