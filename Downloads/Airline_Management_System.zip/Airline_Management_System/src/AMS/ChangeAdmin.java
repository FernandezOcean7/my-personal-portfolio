
package AMS;

import Notifications.AccountCreatedGUI;
import java.awt.Color;
import javax.swing.JFrame;
import Data.adminData;

public class ChangeAdmin extends javax.swing.JFrame {

  
    public ChangeAdmin() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background = new javax.swing.JPanel();
        username = new javax.swing.JLabel();
        password = new javax.swing.JLabel();
        newPassword = new javax.swing.JLabel();
        changeUsername = new javax.swing.JTextField();
        currentPassword = new javax.swing.JPasswordField();
        changePassword = new javax.swing.JPasswordField();
        btnConfirmChanges = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        changeUserError = new javax.swing.JLabel();
        currentPassError = new javax.swing.JLabel();
        changePassError = new javax.swing.JLabel();
        upperborder = new javax.swing.JPanel();
        adminlogin = new javax.swing.JLabel();
        btnexit = new javax.swing.JLabel();
        btnmin = new javax.swing.JLabel();
        showPassword = new javax.swing.JCheckBox();
        changePassword1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        background.setBackground(new java.awt.Color(0, 51, 51));

        username.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setText("Change Username:");

        password.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        password.setForeground(new java.awt.Color(255, 255, 255));
        password.setText("Current Password");

        newPassword.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        newPassword.setForeground(new java.awt.Color(255, 255, 255));
        newPassword.setText("Change Password:");

        changeUsername.setBackground(new java.awt.Color(153, 153, 153));
        changeUsername.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                changeUsernameKeyTyped(evt);
            }
        });

        currentPassword.setBackground(new java.awt.Color(153, 153, 153));
        currentPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                currentPasswordKeyTyped(evt);
            }
        });

        changePassword.setBackground(new java.awt.Color(153, 153, 153));
        changePassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changePasswordActionPerformed(evt);
            }
        });
        changePassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                changePasswordKeyTyped(evt);
            }
        });

        btnConfirmChanges.setBackground(new java.awt.Color(0, 102, 153));
        btnConfirmChanges.setText("Confirm");
        btnConfirmChanges.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmChangesActionPerformed(evt);
            }
        });

        btnCancel.setBackground(new java.awt.Color(255, 102, 0));
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        changeUserError.setFont(new java.awt.Font("Segoe UI Semibold", 3, 8)); // NOI18N
        changeUserError.setForeground(new java.awt.Color(0, 51, 51));
        changeUserError.setText("Insert New Username");

        currentPassError.setFont(new java.awt.Font("Segoe UI Semibold", 3, 8)); // NOI18N
        currentPassError.setForeground(new java.awt.Color(0, 51, 51));
        currentPassError.setText("Insert Current Password");

        changePassError.setFont(new java.awt.Font("Segoe UI Semibold", 3, 8)); // NOI18N
        changePassError.setForeground(new java.awt.Color(0, 51, 51));
        changePassError.setText("Fill in Current Password");

        upperborder.setBackground(new java.awt.Color(204, 102, 0));

        adminlogin.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        adminlogin.setText("Modify Admin");

        btnexit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnexit.setForeground(new java.awt.Color(255, 255, 255));
        btnexit.setText("x");
        btnexit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnexit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnexitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnexitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnexitMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnexitMouseReleased(evt);
            }
        });

        btnmin.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnmin.setForeground(new java.awt.Color(255, 255, 255));
        btnmin.setText("-");
        btnmin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnmin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnminMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnminMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnminMouseExited(evt);
            }
        });

        javax.swing.GroupLayout upperborderLayout = new javax.swing.GroupLayout(upperborder);
        upperborder.setLayout(upperborderLayout);
        upperborderLayout.setHorizontalGroup(
            upperborderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(upperborderLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(adminlogin, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)
                .addComponent(btnmin)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        upperborderLayout.setVerticalGroup(
            upperborderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, upperborderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(adminlogin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnmin, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        showPassword.setForeground(new java.awt.Color(255, 255, 255));
        showPassword.setText("Show Password");
        showPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPasswordActionPerformed(evt);
            }
        });

        changePassword1.setFont(new java.awt.Font("Segoe UI", 3, 10)); // NOI18N
        changePassword1.setForeground(new java.awt.Color(255, 153, 0));
        changePassword1.setText("Go Back");
        changePassword1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        changePassword1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                changePassword1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                changePassword1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                changePassword1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(upperborder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, backgroundLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCancel)
                .addGap(18, 18, 18)
                .addComponent(btnConfirmChanges)
                .addGap(61, 61, 61))
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(changePassword1)
                    .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(backgroundLayout.createSequentialGroup()
                            .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(changeUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(backgroundLayout.createSequentialGroup()
                            .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(currentPassword)
                                .addGroup(backgroundLayout.createSequentialGroup()
                                    .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(currentPassError)
                                        .addComponent(changeUserError))
                                    .addGap(0, 0, Short.MAX_VALUE))))
                        .addGroup(backgroundLayout.createSequentialGroup()
                            .addComponent(newPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(changePassword, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(changePassError)))
                        .addComponent(showPassword, javax.swing.GroupLayout.Alignment.TRAILING)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addComponent(upperborder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(90, 90, 90)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username)
                    .addComponent(changeUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(changeUserError, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password)
                    .addComponent(currentPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(currentPassError)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newPassword)
                    .addComponent(changePassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(changePassError)
                .addGap(2, 2, 2)
                .addComponent(showPassword)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirmChanges)
                    .addComponent(btnCancel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addComponent(changePassword1)
                .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnexitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_btnexitMouseClicked

    private void btnexitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseEntered
        btnexit.setForeground(new Color(255,51,51));
    }//GEN-LAST:event_btnexitMouseEntered

    private void btnexitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseExited
        btnexit.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnexitMouseExited

    private void btnexitMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseReleased

    }//GEN-LAST:event_btnexitMouseReleased

    private void btnminMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_btnminMouseClicked

    private void btnminMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseEntered
        btnmin.setForeground(new Color(255,51,51));
    }//GEN-LAST:event_btnminMouseEntered

    private void btnminMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseExited
        btnmin.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnminMouseExited

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        Login lgi = new Login();
        lgi.setVisible(true);
        lgi.pack();
        this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnConfirmChangesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmChangesActionPerformed
    adminData data = new adminData();
    String changeUser = changeUsername.getText();
    String changePass = new String(changePassword.getPassword());
    String currentPass = new String(currentPassword.getPassword());
        
        if (changeUser.isEmpty() || changePass.isEmpty() || currentPass.isEmpty()) {
            if (changeUser.isEmpty()) {
                changeUserError.setForeground(Color.red); 
            }
            if (currentPass.isEmpty()) {
                currentPassError.setForeground(Color.red);
            }
            if (changePass.isEmpty()) {
                changePassError.setText("Insert New Password");
                changePassError.setForeground(Color.red);
            }
            if (!changePass.isEmpty() && currentPass.isEmpty()) {
                changePassError.setText("Fill in Current Password");
               changePassError.setForeground(Color.red);
            }
        } else {
        if (currentPass.equals(adminData.adminPassword)) {
            adminData.adminPassword = changePass;
            adminData.adminUsername = changeUser;
            AccountCreatedGUI acg = new AccountCreatedGUI();
            acg.setVisible(true);
            
            changePassword.setText("");
            changeUsername.setText("");
            currentPassword.setText("");
        } else {
            currentPassError.setText("Password Does not Match Current Password");
            currentPassError.setForeground(Color.red);
        }
      }    
        
        
        
    }//GEN-LAST:event_btnConfirmChangesActionPerformed

    private void changeUsernameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_changeUsernameKeyTyped
        changeUserError.setForeground(new Color(0,51,51)); 
    }//GEN-LAST:event_changeUsernameKeyTyped

    private void currentPasswordKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_currentPasswordKeyTyped
         currentPassError.setForeground(new Color(0,51,51));
         if (!changePassword.getText().isEmpty()) {
             changePassError.setForeground(new Color(0,51,51));
         }
    }//GEN-LAST:event_currentPasswordKeyTyped

    private void changePasswordKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_changePasswordKeyTyped
       changePassError.setForeground(new Color(0,51,51));
    }//GEN-LAST:event_changePasswordKeyTyped

    private void showPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPasswordActionPerformed
        if (showPassword.isSelected()) {
            currentPassword.setEchoChar((char)0);
            changePassword.setEchoChar((char)0);
        } else {
            currentPassword.setEchoChar('*');
            changePassword.setEchoChar('*');
        }
    }//GEN-LAST:event_showPasswordActionPerformed

    private void changePassword1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changePassword1MouseClicked
        Login lgi = new Login();
            lgi.setVisible(true);
            lgi.pack();
            this.dispose();
    }//GEN-LAST:event_changePassword1MouseClicked

    private void changePassword1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changePassword1MouseEntered
        changePassword.setForeground(Color.ORANGE);
    }//GEN-LAST:event_changePassword1MouseEntered

    private void changePassword1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changePassword1MouseExited
        changePassword.setForeground(new Color(255,153,0));
    }//GEN-LAST:event_changePassword1MouseExited

    private void changePasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changePasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_changePasswordActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ChangeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ChangeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ChangeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ChangeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ChangeAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel adminlogin;
    private javax.swing.JPanel background;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnConfirmChanges;
    private javax.swing.JLabel btnexit;
    private javax.swing.JLabel btnmin;
    private javax.swing.JLabel changePassError;
    private javax.swing.JPasswordField changePassword;
    private javax.swing.JLabel changePassword1;
    private javax.swing.JLabel changeUserError;
    private javax.swing.JTextField changeUsername;
    private javax.swing.JLabel currentPassError;
    private javax.swing.JPasswordField currentPassword;
    private javax.swing.JLabel newPassword;
    private javax.swing.JLabel password;
    private javax.swing.JCheckBox showPassword;
    private javax.swing.JPanel upperborder;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
