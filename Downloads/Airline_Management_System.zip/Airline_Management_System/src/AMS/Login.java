package AMS;

import java.awt.Color;
import javax.swing.JFrame;
import Data.adminData;


public class Login extends javax.swing.JFrame {
    


    public Login() {
        initComponents();
        
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background = new javax.swing.JPanel();
        upperborder = new javax.swing.JPanel();
        adminlogin = new javax.swing.JLabel();
        btnexit = new javax.swing.JLabel();
        btnmin = new javax.swing.JLabel();
        juser = new javax.swing.JLabel();
        jpassword = new javax.swing.JLabel();
        userError = new javax.swing.JLabel();
        userInput = new javax.swing.JTextField();
        passwordInput = new javax.swing.JPasswordField();
        passwordError = new javax.swing.JLabel();
        showPassword = new javax.swing.JCheckBox();
        btnCancel = new javax.swing.JButton();
        btnLogin = new javax.swing.JButton();
        changePassword = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Background.setBackground(new java.awt.Color(0, 51, 51));

        upperborder.setBackground(new java.awt.Color(204, 102, 0));

        adminlogin.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        adminlogin.setText("Admin Login");

        btnexit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnexit.setForeground(new java.awt.Color(255, 255, 255));
        btnexit.setText("x");
        btnexit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnexit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnexitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnexitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnexitMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnexitMouseReleased(evt);
            }
        });

        btnmin.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnmin.setForeground(new java.awt.Color(255, 255, 255));
        btnmin.setText("-");
        btnmin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnmin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnminMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnminMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnminMouseExited(evt);
            }
        });

        javax.swing.GroupLayout upperborderLayout = new javax.swing.GroupLayout(upperborder);
        upperborder.setLayout(upperborderLayout);
        upperborderLayout.setHorizontalGroup(
            upperborderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(upperborderLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(adminlogin, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnmin)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        upperborderLayout.setVerticalGroup(
            upperborderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, upperborderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(adminlogin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnmin, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        juser.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        juser.setForeground(new java.awt.Color(255, 255, 255));
        juser.setText("Username:");

        jpassword.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        jpassword.setForeground(new java.awt.Color(255, 255, 255));
        jpassword.setText("Password:");

        userError.setFont(new java.awt.Font("Segoe UI Semibold", 3, 8)); // NOI18N
        userError.setForeground(new java.awt.Color(0, 51, 51));
        userError.setText("Invalid Username");

        userInput.setBackground(new java.awt.Color(153, 153, 153));
        userInput.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                userInputKeyTyped(evt);
            }
        });

        passwordInput.setBackground(new java.awt.Color(153, 153, 153));
        passwordInput.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                passwordInputKeyTyped(evt);
            }
        });

        passwordError.setFont(new java.awt.Font("Segoe UI Semibold", 3, 8)); // NOI18N
        passwordError.setForeground(new java.awt.Color(0, 51, 51));
        passwordError.setText("Invalid Passoword");

        showPassword.setForeground(new java.awt.Color(255, 255, 255));
        showPassword.setText("Show Password");
        showPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPasswordActionPerformed(evt);
            }
        });

        btnCancel.setBackground(new java.awt.Color(255, 102, 0));
        btnCancel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCancel.setText("  Exit  ");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        btnLogin.setBackground(new java.awt.Color(0, 102, 153));
        btnLogin.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogin.setText("Login");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });

        changePassword.setFont(new java.awt.Font("Segoe UI", 3, 10)); // NOI18N
        changePassword.setForeground(new java.awt.Color(255, 153, 0));
        changePassword.setText("Change Credentials");
        changePassword.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        changePassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                changePasswordMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                changePasswordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                changePasswordMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BackgroundLayout = new javax.swing.GroupLayout(Background);
        Background.setLayout(BackgroundLayout);
        BackgroundLayout.setHorizontalGroup(
            BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BackgroundLayout.createSequentialGroup()
                .addGroup(BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BackgroundLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(userError, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BackgroundLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(changePassword))
                    .addGroup(BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BackgroundLayout.createSequentialGroup()
                            .addGap(107, 107, 107)
                            .addComponent(passwordError, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(showPassword))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BackgroundLayout.createSequentialGroup()
                            .addGap(48, 48, 48)
                            .addGroup(BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(BackgroundLayout.createSequentialGroup()
                                    .addComponent(jpassword)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(BackgroundLayout.createSequentialGroup()
                                    .addComponent(juser)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(userInput, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(61, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BackgroundLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnCancel)
                .addGap(18, 18, 18)
                .addComponent(btnLogin)
                .addGap(113, 113, 113))
            .addComponent(upperborder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BackgroundLayout.setVerticalGroup(
            BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BackgroundLayout.createSequentialGroup()
                .addComponent(upperborder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87)
                .addGroup(BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(juser)
                    .addComponent(userInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userError)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jpassword)
                    .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passwordError)
                    .addComponent(showPassword))
                .addGap(18, 18, 18)
                .addGroup(BackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancel)
                    .addComponent(btnLogin))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(changePassword)
                .addGap(22, 22, 22))
        );

        getContentPane().add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnexitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_btnexitMouseClicked

    private void btnminMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseEntered
        btnmin.setForeground(new Color(255,51,51));
    }//GEN-LAST:event_btnminMouseEntered

    private void btnminMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseClicked
       this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_btnminMouseClicked

    private void btnexitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseEntered
        btnexit.setForeground(new Color(255,51,51));
    }//GEN-LAST:event_btnexitMouseEntered

    private void btnexitMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseReleased
        
    }//GEN-LAST:event_btnexitMouseReleased

    private void btnminMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseExited
        btnmin.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnminMouseExited

    private void btnexitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseExited
       btnexit.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnexitMouseExited

    private void changePasswordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changePasswordMouseEntered
        changePassword.setForeground(Color.ORANGE);
    }//GEN-LAST:event_changePasswordMouseEntered

    private void changePasswordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changePasswordMouseExited
        changePassword.setForeground(new Color(255,153,0));
    }//GEN-LAST:event_changePasswordMouseExited

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
       System.exit(0);
    }//GEN-LAST:event_btnCancelActionPerformed

    private void showPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPasswordActionPerformed
        if (showPassword.isSelected()) {
            passwordInput.setEchoChar((char)0);
        } else passwordInput.setEchoChar('*');
    }//GEN-LAST:event_showPasswordActionPerformed

    private void changePasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changePasswordMouseClicked
        ChangeAdmin ca = new ChangeAdmin();
        ca.setVisible(true);
        ca.pack();
        this.dispose();
    }//GEN-LAST:event_changePasswordMouseClicked

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
    adminData data = new adminData();
        if ((userInput.getText().isEmpty() || !userInput.getText().equals(adminData.adminUsername)) || (passwordInput.getText().isEmpty() || !passwordInput.getText().equals(adminData.adminPassword))) {
            if (userInput.getText().isEmpty() || !userInput.getText().equals(adminData.adminUsername)) {
                userError.setForeground(Color.RED);
            }
            if (passwordInput.getText().isEmpty() || !passwordInput.getText().equals(adminData.adminPassword)) {
                passwordError.setForeground(Color.red);
            }
        }
    if (userInput.getText().equals(adminData.adminUsername) && passwordInput.getText().equals(adminData.adminPassword)) {
    
        Main_GUI main = new Main_GUI();
        main.setVisible(true);
        main.pack();
        this.setVisible(false);
           }
     
    }//GEN-LAST:event_btnLoginActionPerformed

    private void userInputKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_userInputKeyTyped
        userError.setForeground(new Color(0,51,51)); 
    }//GEN-LAST:event_userInputKeyTyped

    private void passwordInputKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passwordInputKeyTyped
        passwordError.setForeground(new Color(0,51,51));
    }//GEN-LAST:event_passwordInputKeyTyped

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background;
    private javax.swing.JLabel adminlogin;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnLogin;
    private javax.swing.JLabel btnexit;
    private javax.swing.JLabel btnmin;
    private javax.swing.JLabel changePassword;
    private javax.swing.JLabel jpassword;
    private javax.swing.JLabel juser;
    private javax.swing.JLabel passwordError;
    private javax.swing.JPasswordField passwordInput;
    private javax.swing.JCheckBox showPassword;
    private javax.swing.JPanel upperborder;
    private javax.swing.JLabel userError;
    private javax.swing.JTextField userInput;
    // End of variables declaration//GEN-END:variables
}
