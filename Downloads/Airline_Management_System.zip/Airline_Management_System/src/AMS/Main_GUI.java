
package AMS;

import Notifications.WarnData;
import Data.*;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;     
import EditTables.*;



public class Main_GUI extends javax.swing.JFrame {
  
 
    public Main_GUI() {
        initComponents();
        
      if (WarnData.planeTableModel != null) {
          planeTable.setModel(WarnData.planeTableModel);
      }
      if (WarnData.airportTableModel != null) {
          airportTable.setModel(WarnData.airportTableModel);
      }
      if (WarnData.employeeTableModel != null) {
          employeeTable.setModel(WarnData.employeeTableModel);
      }
      if (WarnData.passengerTableModel != null) {
          passengerTable.setModel(WarnData.passengerTableModel);
      }
      if (WarnData.flightTableModel != null) {
          flightsTable.setModel(WarnData.flightTableModel);
      }
      
      
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        border = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnmin = new javax.swing.JLabel();
        btnexit = new javax.swing.JLabel();
        btnHome = new javax.swing.JLabel();
        btnFlights = new javax.swing.JLabel();
        btnPassengers = new javax.swing.JLabel();
        btnEmployees = new javax.swing.JLabel();
        btnPlanes = new javax.swing.JLabel();
        btnAirport = new javax.swing.JLabel();
        tabPanel = new javax.swing.JTabbedPane();
        homeTab = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        btnExit = new javax.swing.JLabel();
        small = new javax.swing.JPanel();
        flightsTab = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        addFlight = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        flightsTable = new javax.swing.JTable();
        passengerTab = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        passengerTable = new javax.swing.JTable();
        addEmployee1 = new javax.swing.JButton();
        employeesTab = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        employeeTable = new javax.swing.JTable();
        addEmployee = new javax.swing.JButton();
        planesTab = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        planeTable = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        addPlane = new javax.swing.JButton();
        airportTab = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        airportTable = new javax.swing.JTable();
        addAirport = new javax.swing.JButton();

        jLabel7.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Flight");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1040, 556));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        border.setBackground(new java.awt.Color(204, 102, 0));
        border.setPreferredSize(new java.awt.Dimension(1040, 90));

        jPanel1.setBackground(new java.awt.Color(230, 126, 34));

        jPanel2.setBackground(new java.awt.Color(243, 156, 18));

        jPanel3.setBackground(new java.awt.Color(241, 196, 15));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1039, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
        );

        btnmin.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnmin.setForeground(new java.awt.Color(255, 255, 255));
        btnmin.setText("-");
        btnmin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnmin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnminMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnminMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnminMouseExited(evt);
            }
        });

        btnexit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnexit.setForeground(new java.awt.Color(255, 255, 255));
        btnexit.setText("x");
        btnexit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnexit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnexitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnexitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnexitMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnexitMouseReleased(evt);
            }
        });

        btnHome.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        btnHome.setForeground(new java.awt.Color(255, 255, 255));
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/home.png"))); // NOI18N
        btnHome.setText("Home");
        btnHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnHomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnHomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnHomeMouseExited(evt);
            }
        });

        btnFlights.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        btnFlights.setForeground(new java.awt.Color(255, 255, 255));
        btnFlights.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/direct-flight.png"))); // NOI18N
        btnFlights.setText("Flights");
        btnFlights.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFlightsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnFlightsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnFlightsMouseExited(evt);
            }
        });

        btnPassengers.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        btnPassengers.setForeground(new java.awt.Color(255, 255, 255));
        btnPassengers.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/group (1).png"))); // NOI18N
        btnPassengers.setText("Passengers");
        btnPassengers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnPassengersMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnPassengersMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnPassengersMouseExited(evt);
            }
        });

        btnEmployees.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        btnEmployees.setForeground(new java.awt.Color(255, 255, 255));
        btnEmployees.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/support.png"))); // NOI18N
        btnEmployees.setText("Employees");
        btnEmployees.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEmployeesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEmployeesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEmployeesMouseExited(evt);
            }
        });

        btnPlanes.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        btnPlanes.setForeground(new java.awt.Color(255, 255, 255));
        btnPlanes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/airplane.png"))); // NOI18N
        btnPlanes.setText("Planes");
        btnPlanes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnPlanesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnPlanesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnPlanesMouseExited(evt);
            }
        });

        btnAirport.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        btnAirport.setForeground(new java.awt.Color(255, 255, 255));
        btnAirport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/airport.png"))); // NOI18N
        btnAirport.setText("Airport");
        btnAirport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAirportMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAirportMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAirportMouseExited(evt);
            }
        });

        javax.swing.GroupLayout borderLayout = new javax.swing.GroupLayout(border);
        border.setLayout(borderLayout);
        borderLayout.setHorizontalGroup(
            borderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, borderLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(btnHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(36, 36, 36)
                .addComponent(btnFlights, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(38, 38, 38)
                .addComponent(btnPassengers, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(38, 38, 38)
                .addComponent(btnEmployees, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(37, 37, 37)
                .addComponent(btnPlanes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(41, 41, 41)
                .addComponent(btnAirport, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(137, 137, 137)
                .addComponent(btnmin)
                .addGap(18, 18, 18)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(356, 356, 356))
        );
        borderLayout.setVerticalGroup(
            borderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(borderLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(borderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnmin, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnHome)
                    .addComponent(btnFlights)
                    .addComponent(btnPassengers)
                    .addComponent(btnEmployees)
                    .addComponent(btnPlanes)
                    .addComponent(btnAirport))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(border, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 90));

        homeTab.setBackground(new java.awt.Color(0, 51, 51));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/airplane_V4.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.setPreferredSize(new java.awt.Dimension(500, 468));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 63)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 102, 0));
        jLabel1.setText("Java");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 82)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 153));
        jLabel3.setText("Airline");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 57)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 102, 0));
        jLabel4.setText("Management");

        jPanel4.setBackground(new java.awt.Color(204, 102, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 570, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(0, 153, 153));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 450, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(241, 196, 15));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        btnExit.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btnExit.setForeground(new java.awt.Color(255, 153, 0));
        btnExit.setText("EXIT");
        btnExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnExitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnExitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnExitMouseExited(evt);
            }
        });

        small.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout smallLayout = new javax.swing.GroupLayout(small);
        small.setLayout(smallLayout);
        smallLayout.setHorizontalGroup(
            smallLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 170, Short.MAX_VALUE)
        );
        smallLayout.setVerticalGroup(
            smallLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 17, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout homeTabLayout = new javax.swing.GroupLayout(homeTab);
        homeTab.setLayout(homeTabLayout);
        homeTabLayout.setHorizontalGroup(
            homeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeTabLayout.createSequentialGroup()
                .addGroup(homeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(homeTabLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(homeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(homeTabLayout.createSequentialGroup()
                                .addGap(190, 190, 190)
                                .addComponent(jLabel3))
                            .addComponent(jLabel4)
                            .addGroup(homeTabLayout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(jLabel1))))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(homeTabLayout.createSequentialGroup()
                        .addGap(450, 450, 450)
                        .addComponent(small, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(homeTabLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        homeTabLayout.setVerticalGroup(
            homeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeTabLayout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addGroup(homeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(homeTabLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jLabel4))
                    .addGroup(homeTabLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1)))
                .addGap(203, 203, 203)
                .addGroup(homeTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(homeTabLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(homeTabLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(small, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnExit))
            .addGroup(homeTabLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        tabPanel.addTab("tab1", homeTab);

        flightsTab.setBackground(new java.awt.Color(0, 51, 51));

        jLabel5.setFont(new java.awt.Font("Sitka Text", 3, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 102, 0));
        jLabel5.setText("Flight");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 153));
        jLabel6.setText("Manager");

        addFlight.setBackground(new java.awt.Color(0, 102, 153));
        addFlight.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        addFlight.setForeground(new java.awt.Color(255, 255, 255));
        addFlight.setText("Add Flight");
        addFlight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addFlightActionPerformed(evt);
            }
        });

        flightsTable.setBackground(new java.awt.Color(0, 51, 51));
        flightsTable.setForeground(new java.awt.Color(255, 255, 255));
        flightsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Airplane", "Origin", "Destination", "Departure", "Arrival", "Status", "Economy", "Business"
            }
        ));
        flightsTable.setGridColor(new java.awt.Color(204, 102, 0));
        flightsTable.setSelectionBackground(new java.awt.Color(204, 102, 0));
        flightsTable.setShowGrid(false);
        flightsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                flightsTableMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(flightsTable);

        javax.swing.GroupLayout flightsTabLayout = new javax.swing.GroupLayout(flightsTab);
        flightsTab.setLayout(flightsTabLayout);
        flightsTabLayout.setHorizontalGroup(
            flightsTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(flightsTabLayout.createSequentialGroup()
                .addGroup(flightsTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(flightsTabLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(596, 596, 596)
                        .addComponent(addFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(flightsTabLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 1028, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(1320, Short.MAX_VALUE))
        );
        flightsTabLayout.setVerticalGroup(
            flightsTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(flightsTabLayout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addGroup(flightsTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(addFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabPanel.addTab("tab2", flightsTab);

        passengerTab.setBackground(new java.awt.Color(0, 51, 51));

        jLabel14.setFont(new java.awt.Font("Sitka Text", 3, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(204, 102, 0));
        jLabel14.setText("Passengers");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 153, 153));
        jLabel15.setText("Manager");

        passengerTable.setBackground(new java.awt.Color(0, 51, 51));
        passengerTable.setForeground(new java.awt.Color(255, 255, 255));
        passengerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Tel", "Email"
            }
        ));
        passengerTable.setGridColor(new java.awt.Color(204, 102, 0));
        passengerTable.setSelectionBackground(new java.awt.Color(204, 102, 0));
        passengerTable.setShowGrid(false);
        passengerTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                passengerTableMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(passengerTable);

        addEmployee1.setBackground(new java.awt.Color(0, 102, 153));
        addEmployee1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        addEmployee1.setForeground(new java.awt.Color(255, 255, 255));
        addEmployee1.setText("Add Passenger");
        addEmployee1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addEmployee1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout passengerTabLayout = new javax.swing.GroupLayout(passengerTab);
        passengerTab.setLayout(passengerTabLayout);
        passengerTabLayout.setHorizontalGroup(
            passengerTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(passengerTabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(passengerTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(passengerTabLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(493, 493, 493)
                        .addComponent(addEmployee1))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 1028, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1320, Short.MAX_VALUE))
        );
        passengerTabLayout.setVerticalGroup(
            passengerTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, passengerTabLayout.createSequentialGroup()
                .addContainerGap(83, Short.MAX_VALUE)
                .addGroup(passengerTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, passengerTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(addEmployee1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabPanel.addTab("tab3", passengerTab);

        employeesTab.setBackground(new java.awt.Color(0, 51, 51));

        jLabel12.setFont(new java.awt.Font("Sitka Text", 3, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 102, 0));
        jLabel12.setText("Employees");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 153, 153));
        jLabel13.setText("Manager");

        employeeTable.setBackground(new java.awt.Color(0, 51, 51));
        employeeTable.setForeground(new java.awt.Color(255, 255, 255));
        employeeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Tel", "Email", "Salary", "Job Title"
            }
        ));
        employeeTable.setGridColor(new java.awt.Color(204, 102, 0));
        employeeTable.setSelectionBackground(new java.awt.Color(204, 102, 0));
        employeeTable.setShowGrid(false);
        employeeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                employeeTableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(employeeTable);

        addEmployee.setBackground(new java.awt.Color(0, 102, 153));
        addEmployee.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        addEmployee.setForeground(new java.awt.Color(255, 255, 255));
        addEmployee.setText("Add Employee");
        addEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addEmployeeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout employeesTabLayout = new javax.swing.GroupLayout(employeesTab);
        employeesTab.setLayout(employeesTabLayout);
        employeesTabLayout.setHorizontalGroup(
            employeesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(employeesTabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(employeesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(employeesTabLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(502, 502, 502)
                        .addComponent(addEmployee))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 1028, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1320, Short.MAX_VALUE))
        );
        employeesTabLayout.setVerticalGroup(
            employeesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, employeesTabLayout.createSequentialGroup()
                .addContainerGap(83, Short.MAX_VALUE)
                .addGroup(employeesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, employeesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(addEmployee, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabPanel.addTab("tab4", employeesTab);

        planesTab.setBackground(new java.awt.Color(0, 51, 51));

        planeTable.setBackground(new java.awt.Color(0, 51, 51));
        planeTable.setForeground(new java.awt.Color(255, 255, 255));
        planeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Economy Capacity", "Business Capacity", "Model"
            }
        ));
        planeTable.setGridColor(new java.awt.Color(204, 102, 0));
        planeTable.setSelectionBackground(new java.awt.Color(204, 102, 0));
        planeTable.setShowGrid(false);
        planeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                planeTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(planeTable);

        jLabel8.setFont(new java.awt.Font("Sitka Text", 3, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 102, 0));
        jLabel8.setText("Planes");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 153, 153));
        jLabel9.setText("Manager");

        addPlane.setBackground(new java.awt.Color(0, 102, 153));
        addPlane.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        addPlane.setForeground(new java.awt.Color(255, 255, 255));
        addPlane.setText("Add Plane");
        addPlane.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPlaneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout planesTabLayout = new javax.swing.GroupLayout(planesTab);
        planesTab.setLayout(planesTabLayout);
        planesTabLayout.setHorizontalGroup(
            planesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(planesTabLayout.createSequentialGroup()
                .addGroup(planesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(planesTabLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(602, 602, 602)
                        .addComponent(addPlane, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(planesTabLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1028, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(1320, Short.MAX_VALUE))
        );
        planesTabLayout.setVerticalGroup(
            planesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(planesTabLayout.createSequentialGroup()
                .addContainerGap(83, Short.MAX_VALUE)
                .addGroup(planesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addPlane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, planesTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabPanel.addTab("tab5", planesTab);

        airportTab.setBackground(new java.awt.Color(0, 51, 51));

        jLabel10.setFont(new java.awt.Font("Sitka Text", 3, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 102, 0));
        jLabel10.setText("Airports");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 153, 153));
        jLabel11.setText("Manager");

        airportTable.setBackground(new java.awt.Color(0, 51, 51));
        airportTable.setForeground(new java.awt.Color(255, 255, 255));
        airportTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Location"
            }
        ));
        airportTable.setGridColor(new java.awt.Color(204, 102, 0));
        airportTable.setSelectionBackground(new java.awt.Color(204, 102, 0));
        airportTable.setShowGrid(false);
        airportTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                airportTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(airportTable);
        if (airportTable.getColumnModel().getColumnCount() > 0) {
            airportTable.getColumnModel().getColumn(0).setResizable(false);
        }

        addAirport.setBackground(new java.awt.Color(0, 102, 153));
        addAirport.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        addAirport.setForeground(new java.awt.Color(255, 255, 255));
        addAirport.setText("Add Airport");
        addAirport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAirportActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout airportTabLayout = new javax.swing.GroupLayout(airportTab);
        airportTab.setLayout(airportTabLayout);
        airportTabLayout.setHorizontalGroup(
            airportTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(airportTabLayout.createSequentialGroup()
                .addGroup(airportTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(airportTabLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel10)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(563, 563, 563)
                        .addComponent(addAirport))
                    .addGroup(airportTabLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1028, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(1320, 1320, 1320))
        );
        airportTabLayout.setVerticalGroup(
            airportTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(airportTabLayout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addGroup(airportTabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(airportTabLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(airportTabLayout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(addAirport, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabPanel.addTab("tab6", airportTab);

        getContentPane().add(tabPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -34, -1, 590));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMouseClicked
        WarnData.planeTableModel = (DefaultTableModel) planeTable.getModel();
        WarnData.airportTableModel = (DefaultTableModel) airportTable.getModel();
        WarnData.employeeTableModel = (DefaultTableModel) employeeTable.getModel();
        WarnData.passengerTableModel = (DefaultTableModel) passengerTable.getModel();
        WarnData.flightTableModel = (DefaultTableModel) flightsTable.getModel();
        Login lgn = new Login();
        lgn.setVisible(true);
        lgn.pack();
        this.setVisible(false);
        
    }//GEN-LAST:event_btnExitMouseClicked

    private void btnExitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMouseEntered
        btnExit.setForeground(Color.ORANGE);
    }//GEN-LAST:event_btnExitMouseEntered

    private void btnExitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMouseExited
        btnExit.setForeground(new Color(255,153,0));             
    }//GEN-LAST:event_btnExitMouseExited

    private void btnminMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_btnminMouseClicked

    private void btnminMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseEntered
        btnmin.setForeground(new Color(255,51,51));
    }//GEN-LAST:event_btnminMouseEntered

    private void btnminMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnminMouseExited
        btnmin.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnminMouseExited

    private void btnexitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_btnexitMouseClicked

    private void btnexitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseEntered
        btnexit.setForeground(new Color(255,51,51));
    }//GEN-LAST:event_btnexitMouseEntered

    private void btnexitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseExited
        btnexit.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnexitMouseExited

    private void btnexitMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnexitMouseReleased

    }//GEN-LAST:event_btnexitMouseReleased

    private void btnAirportMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAirportMouseEntered
        btnAirport.setForeground(new Color(241,196,15));
    }//GEN-LAST:event_btnAirportMouseEntered

    private void btnHomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseEntered
        btnHome.setForeground(new Color(241,196,15));
    }//GEN-LAST:event_btnHomeMouseEntered

    private void btnHomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseExited
        btnHome.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnHomeMouseExited

    private void btnFlightsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFlightsMouseEntered
        btnFlights.setForeground(new Color(241,196,15));
    }//GEN-LAST:event_btnFlightsMouseEntered

    private void btnFlightsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFlightsMouseExited
        btnFlights.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnFlightsMouseExited

    private void btnPassengersMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPassengersMouseEntered
        btnPassengers.setForeground(new Color(241,196,15));
    }//GEN-LAST:event_btnPassengersMouseEntered

    private void btnPassengersMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPassengersMouseExited
        btnPassengers.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnPassengersMouseExited

    private void btnEmployeesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmployeesMouseEntered
        btnEmployees.setForeground(new Color(241,196,15));
    }//GEN-LAST:event_btnEmployeesMouseEntered

    private void btnEmployeesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmployeesMouseExited
        btnEmployees.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnEmployeesMouseExited

    private void btnPlanesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPlanesMouseEntered
       btnPlanes.setForeground(new Color(241,196,15));
    }//GEN-LAST:event_btnPlanesMouseEntered

    private void btnPlanesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPlanesMouseExited
        btnPlanes.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnPlanesMouseExited

    private void btnAirportMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAirportMouseExited
        btnAirport.setForeground(Color.WHITE);
    }//GEN-LAST:event_btnAirportMouseExited

    private void btnHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseClicked
        tabPanel.setSelectedIndex(0);
    }//GEN-LAST:event_btnHomeMouseClicked

    private void btnFlightsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFlightsMouseClicked
        tabPanel.setSelectedIndex(1);
    }//GEN-LAST:event_btnFlightsMouseClicked

    private void btnPassengersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPassengersMouseClicked
        tabPanel.setSelectedIndex(2);
    }//GEN-LAST:event_btnPassengersMouseClicked

    private void btnEmployeesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmployeesMouseClicked
        tabPanel.setSelectedIndex(3);
    }//GEN-LAST:event_btnEmployeesMouseClicked

    private void btnPlanesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPlanesMouseClicked
        tabPanel.setSelectedIndex(4);    }//GEN-LAST:event_btnPlanesMouseClicked

    private void btnAirportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAirportMouseClicked
        tabPanel.setSelectedIndex(5); 
    }//GEN-LAST:event_btnAirportMouseClicked

    private void addPlaneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPlaneActionPerformed
    planesData pd = new planesData(this);
    pd.setVisible(true);
    pd.pack();
    }//GEN-LAST:event_addPlaneActionPerformed

    private void addAirportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addAirportActionPerformed
       airportsData ad = new airportsData(this);
       ad.setVisible(true);
       ad.pack();
       
    }//GEN-LAST:event_addAirportActionPerformed

    private void addEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addEmployeeActionPerformed
        employeesData ed = new employeesData(this);
        ed.setVisible(true);
        ed.pack();
        
    }//GEN-LAST:event_addEmployeeActionPerformed

    private void addEmployee1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addEmployee1ActionPerformed
        passengersData pd = new passengersData(this);
        pd.setVisible(true);
        pd.pack();
    }//GEN-LAST:event_addEmployee1ActionPerformed

    private void addFlightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addFlightActionPerformed
        flightsData fd = new flightsData(this);
        fd.setVisible(true);
        fd.pack();
        
    }//GEN-LAST:event_addFlightActionPerformed

    private void planeTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_planeTableMouseClicked

       EditPlaneTable ept = new EditPlaneTable(this);
       ept.pack();
       ept.setVisible(true);
    }//GEN-LAST:event_planeTableMouseClicked

    private void airportTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_airportTableMouseClicked
       EditAirportTable eat = new EditAirportTable(this);
       eat.pack();
       eat.setVisible(true);
    }//GEN-LAST:event_airportTableMouseClicked

    private void employeeTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_employeeTableMouseClicked
       EditEmployeeTable eet = new EditEmployeeTable(this);
       eet.pack();
       eet.setVisible(true);
    }//GEN-LAST:event_employeeTableMouseClicked

    private void passengerTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passengerTableMouseClicked
        int selectedRow = passengerTable.getSelectedRow();
        EditPassngerTable ep = new EditPassngerTable (this, selectedRow);
        ep.pack();
        ep.setVisible(true);
    }//GEN-LAST:event_passengerTableMouseClicked

    private void flightsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_flightsTableMouseClicked
        FlightOption fo = new FlightOption(this);
        fo.pack();
        fo.setVisible(true);
        
    }//GEN-LAST:event_flightsTableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main_GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addAirport;
    private javax.swing.JButton addEmployee;
    private javax.swing.JButton addEmployee1;
    private javax.swing.JButton addFlight;
    private javax.swing.JButton addPlane;
    private javax.swing.JPanel airportTab;
    public javax.swing.JTable airportTable;
    private javax.swing.JPanel border;
    private javax.swing.JLabel btnAirport;
    private javax.swing.JLabel btnEmployees;
    private javax.swing.JLabel btnExit;
    private javax.swing.JLabel btnFlights;
    private javax.swing.JLabel btnHome;
    private javax.swing.JLabel btnPassengers;
    private javax.swing.JLabel btnPlanes;
    private javax.swing.JLabel btnexit;
    private javax.swing.JLabel btnmin;
    public javax.swing.JTable employeeTable;
    private javax.swing.JPanel employeesTab;
    private javax.swing.JPanel flightsTab;
    public javax.swing.JTable flightsTable;
    private javax.swing.JPanel homeTab;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JPanel passengerTab;
    public javax.swing.JTable passengerTable;
    public javax.swing.JTable planeTable;
    private javax.swing.JPanel planesTab;
    private javax.swing.JPanel small;
    private javax.swing.JTabbedPane tabPanel;
    // End of variables declaration//GEN-END:variables
}
