
package AMS;



public class Staff extends javax.swing.JFrame {
private Main_GUI mainGUI;
private String flightID;


    public Staff(Main_GUI mainGUI, String flightID) {
        initComponents();
        this.mainGUI = mainGUI;
        this.flightID = flightID;
        viewStaffTable.setModel(Notifications.WarnData.getStaffModelForFlight(flightID));
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.JPanel a = new javax.swing.JPanel();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        Return = new javax.swing.JButton();
        ecoCap = new javax.swing.JLabel();
        busCap = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        viewStaffTable = new javax.swing.JTable();
        txt = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        a.setBackground(new java.awt.Color(0, 51, 51));
        a.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 102, 0), 2));
        a.setPreferredSize(new java.awt.Dimension(470, 474));
        a.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(204, 102, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Flight Staff");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        a.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 939, -1));

        Return.setBackground(new java.awt.Color(204, 102, 0));
        Return.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        Return.setText("Return");
        Return.setPreferredSize(new java.awt.Dimension(114, 23));
        Return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnActionPerformed(evt);
            }
        });
        a.add(Return, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 470, -1, 33));

        ecoCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        ecoCap.setForeground(new java.awt.Color(255, 255, 255));
        a.add(ecoCap, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 567, 113, -1));

        busCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        busCap.setForeground(new java.awt.Color(255, 255, 255));
        a.add(busCap, new org.netbeans.lib.awtextra.AbsoluteConstraints(499, 567, 147, -1));

        viewStaffTable.setBackground(new java.awt.Color(0, 51, 51));
        viewStaffTable.setForeground(new java.awt.Color(255, 255, 255));
        viewStaffTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Tel#", "Email", "Salary", "Job Title"
            }
        ));
        viewStaffTable.setGridColor(new java.awt.Color(204, 102, 0));
        viewStaffTable.setSelectionBackground(new java.awt.Color(204, 102, 0));
        jScrollPane1.setViewportView(viewStaffTable);

        a.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 913, 322));

        txt.setFont(new java.awt.Font("Segoe UI Black", 0, 48)); // NOI18N
        txt.setForeground(new java.awt.Color(204, 102, 0));
        txt.setText("Staff");
        txt.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        a.add(txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(a, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 943, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(a, javax.swing.GroupLayout.PREFERRED_SIZE, 522, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnActionPerformed
        FlightOption fo = new FlightOption(mainGUI);
       fo.setVisible(true);
       fo.pack();
        this.dispose();
    }//GEN-LAST:event_ReturnActionPerformed

    private void txtAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtAncestorAdded

    }//GEN-LAST:event_txtAncestorAdded

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Return;
    private javax.swing.JLabel busCap;
    private javax.swing.JLabel ecoCap;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel txt;
    public static javax.swing.JTable viewStaffTable;
    // End of variables declaration//GEN-END:variables
}
