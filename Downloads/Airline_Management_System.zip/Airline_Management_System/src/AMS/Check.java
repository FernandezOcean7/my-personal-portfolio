
package AMS;


public class Check {
    
    public static boolean isNumber(String text) {
    try {
        Integer.parseInt(text); 
        return true;             
    } catch (NumberFormatException e) {
        return false;           
    }
}
      
       public static boolean containsNumber(String text) {
        
        if (text.contains("1") || text.contains("2") || text.contains("3") || text.contains("4") || text.contains("5") || text.contains("6") || text.contains("7") || text.contains("8") || text.contains("9")) {
            return true;
        } else return false;
    }
        
      
}
