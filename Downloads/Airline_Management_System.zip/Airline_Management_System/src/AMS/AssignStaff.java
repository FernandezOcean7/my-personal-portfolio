
package AMS;

import Notifications.staffAssigned;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;


public class AssignStaff extends javax.swing.JFrame {
private JComboBox<String>[] staffCombos;
private JLabel[] emailLabels;
private JLabel[] telLabels;
private JLabel[] positionLabels;
private JLabel[] removeButtons;
private java.util.List<String> allStaffNames = new java.util.ArrayList<>();
private javax.swing.table.DefaultTableModel employeeModel;

private Main_GUI mainGUI;
private String flightID;


   
    public AssignStaff(Main_GUI mainGUI, String flightID) {
        initComponents();
            this.mainGUI = mainGUI;
            this.flightID = flightID;
         
                    

    
    staffCombos = new JComboBox[]{combo1, combo2, combo3, combo4, combo5, combo6, combo7, combo8, combo9, combo10};
    emailLabels = new JLabel[]{e1, e2, e3, e4, e5, e6, e7, e8, e9, e10};
    telLabels = new JLabel[]{t1, t2, t3, t4, t5, t6, t7, t8, t9, t10};
    positionLabels = new JLabel[]{p1, p2, p3, p4, p5, p6, p7, p8, p9, p10};
    removeButtons = new JLabel[]{remove1, remove2, remove3, remove4, remove5, remove6, remove7, remove8, remove9, remove10};

   
    employeeModel = (DefaultTableModel) mainGUI.employeeTable.getModel();
                
        for (int i = 0; i < mainGUI.employeeTable.getRowCount(); i++) {
        String name = mainGUI.employeeTable.getValueAt(i, 1).toString();
        allStaffNames.add(name);
    }


    for (JComboBox combo : staffCombos) {
            combo1.setSelectedIndex(-1);
            combo2.setSelectedIndex(-1);
            combo3.setSelectedIndex(-1);
            combo4.setSelectedIndex(-1);
            combo5.setSelectedIndex(-1);
            combo6.setSelectedIndex(-1);
            combo7.setSelectedIndex(-1);
            combo8.setSelectedIndex(-1);
            combo9.setSelectedIndex(-1);
            combo10.setSelectedIndex(-1);
        for (String name : allStaffNames) {
            combo.addItem(name);
            combo1.setSelectedIndex(-1);
            combo2.setSelectedIndex(-1);
            combo3.setSelectedIndex(-1);
            combo4.setSelectedIndex(-1);
            combo5.setSelectedIndex(-1);
            combo6.setSelectedIndex(-1);
            combo7.setSelectedIndex(-1);
            combo8.setSelectedIndex(-1);
            combo9.setSelectedIndex(-1);
            combo10.setSelectedIndex(-1);
        }
    }

    for (int i = 0; i < staffCombos.length; i++) {
        final int index = i;
        staffCombos[i].addActionListener(e -> {
            String selectedName = (String) staffCombos[index].getSelectedItem();
            if (selectedName != null && !selectedName.isEmpty()) {
            updateEmployeeInfo(selectedName, index);
            refreshComboOptions();
            }
        });
    }
      for (int i = 0; i < removeButtons.length; i++) {
        final int index = i;
        removeButtons[i].addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                
                staffCombos[index].setSelectedIndex(-1);

                
                emailLabels[index].setText("Email");
                telLabels[index].setText("Tel#");
                positionLabels[index].setText("Position");
                refreshComboOptions();

            }
        });
      }
    
                
    }
    
    private void updateEmployeeInfo(String selectedName, int index) {
    if (selectedName == null || selectedName.isEmpty()) {
        emailLabels[index].setText("Email");
        telLabels[index].setText("Tel#");
        positionLabels[index].setText("Position");
        return;
    }

    for (int i = 0; i < employeeModel.getRowCount(); i++) {
        if (employeeModel.getValueAt(i, 1).toString().equals(selectedName)) {
            positionLabels[index].setText(employeeModel.getValueAt(i, 5).toString());
            telLabels[index].setText(employeeModel.getValueAt(i, 2).toString());
            emailLabels[index].setText(employeeModel.getValueAt(i, 3).toString());
            break;
        }
    }
}
    
    private void refreshComboOptions() {
    java.util.List<String> selected = new java.util.ArrayList<>();
    for (JComboBox<String> combo : staffCombos) {
        String val = (String) combo.getSelectedItem();
        if (val != null && !val.isEmpty()) selected.add(val);
    }

    for (JComboBox<String> combo : staffCombos) {
        String current = (String) combo.getSelectedItem();
        combo.removeAllItems();
        combo.addItem("");

        for (int i = 0; i < employeeModel.getRowCount(); i++) {
            String name = employeeModel.getValueAt(i, 1).toString();
            if (!selected.contains(name) || name.equals(current)) {
                combo.addItem(name);
            }
        }

        combo.setSelectedItem(current);
    }
}
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox4 = new javax.swing.JComboBox<>();
        javax.swing.JPanel jPanel1 = new javax.swing.JPanel();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        ecoCap = new javax.swing.JLabel();
        busCap = new javax.swing.JLabel();
        combo10 = new javax.swing.JComboBox<>();
        javax.swing.JLabel jLabel3 = new javax.swing.JLabel();
        e1 = new javax.swing.JLabel();
        t1 = new javax.swing.JLabel();
        e2 = new javax.swing.JLabel();
        e4 = new javax.swing.JLabel();
        e3 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel10 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel11 = new javax.swing.JLabel();
        p1 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel13 = new javax.swing.JLabel();
        t2 = new javax.swing.JLabel();
        p2 = new javax.swing.JLabel();
        t4 = new javax.swing.JLabel();
        t3 = new javax.swing.JLabel();
        p4 = new javax.swing.JLabel();
        p3 = new javax.swing.JLabel();
        e8 = new javax.swing.JLabel();
        e7 = new javax.swing.JLabel();
        e6 = new javax.swing.JLabel();
        e5 = new javax.swing.JLabel();
        t5 = new javax.swing.JLabel();
        t6 = new javax.swing.JLabel();
        t7 = new javax.swing.JLabel();
        t8 = new javax.swing.JLabel();
        p8 = new javax.swing.JLabel();
        p7 = new javax.swing.JLabel();
        p6 = new javax.swing.JLabel();
        p5 = new javax.swing.JLabel();
        e10 = new javax.swing.JLabel();
        e9 = new javax.swing.JLabel();
        t10 = new javax.swing.JLabel();
        t9 = new javax.swing.JLabel();
        p10 = new javax.swing.JLabel();
        p9 = new javax.swing.JLabel();
        combo1 = new javax.swing.JComboBox<>();
        combo2 = new javax.swing.JComboBox<>();
        combo3 = new javax.swing.JComboBox<>();
        combo4 = new javax.swing.JComboBox<>();
        combo5 = new javax.swing.JComboBox<>();
        combo6 = new javax.swing.JComboBox<>();
        combo7 = new javax.swing.JComboBox<>();
        combo8 = new javax.swing.JComboBox<>();
        combo9 = new javax.swing.JComboBox<>();
        remove10 = new javax.swing.JLabel();
        remove1 = new javax.swing.JLabel();
        remove2 = new javax.swing.JLabel();
        remove3 = new javax.swing.JLabel();
        remove4 = new javax.swing.JLabel();
        remove5 = new javax.swing.JLabel();
        remove6 = new javax.swing.JLabel();
        remove7 = new javax.swing.JLabel();
        remove8 = new javax.swing.JLabel();
        remove9 = new javax.swing.JLabel();

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(0, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 102, 0), 2));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(204, 102, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Assign Staff");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 756, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, -1, -1));

        submit.setBackground(new java.awt.Color(204, 102, 0));
        submit.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        submit.setText("Sumbit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });
        jPanel1.add(submit, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 440, 87, -1));

        cancel.setBackground(new java.awt.Color(204, 102, 0));
        cancel.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        jPanel1.add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 440, 87, -1));

        ecoCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        ecoCap.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(ecoCap, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 204, 113, -1));

        busCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        busCap.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(busCap, new org.netbeans.lib.awtextra.AbsoluteConstraints(207, 204, 147, -1));

        combo10.setBackground(new java.awt.Color(255, 153, 0));
        combo10.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo10, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 400, 80, 20));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Name");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 72, -1));

        e1.setBackground(new java.awt.Color(255, 255, 255));
        e1.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e1.setForeground(new java.awt.Color(204, 102, 0));
        e1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e1.setText("Email");
        e1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 190, -1));

        t1.setBackground(new java.awt.Color(255, 255, 255));
        t1.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t1.setForeground(new java.awt.Color(204, 102, 0));
        t1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t1.setText("Tel#");
        t1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, 179, -1));

        e2.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e2.setForeground(new java.awt.Color(255, 153, 51));
        e2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e2.setText("Email");
        e2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 188, -1));

        e4.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e4.setForeground(new java.awt.Color(255, 153, 51));
        e4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e4.setText("Email");
        e4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 188, -1));

        e3.setBackground(new java.awt.Color(255, 255, 255));
        e3.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e3.setForeground(new java.awt.Color(204, 102, 0));
        e3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e3.setText("Email");
        e3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 188, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Email");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 188, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Tel#");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 90, 179, -1));

        p1.setBackground(new java.awt.Color(255, 255, 255));
        p1.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p1.setForeground(new java.awt.Color(204, 102, 0));
        p1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p1.setText("Position");
        p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 130, 204, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Position");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 90, 204, -1));

        t2.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t2.setForeground(new java.awt.Color(255, 153, 51));
        t2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t2.setText("Tel#");
        t2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 160, 179, -1));

        p2.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p2.setForeground(new java.awt.Color(255, 153, 51));
        p2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p2.setText("Position");
        p2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 160, 204, -1));

        t4.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t4.setForeground(new java.awt.Color(255, 153, 51));
        t4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t4.setText("Tel#");
        t4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t4, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 220, 179, -1));

        t3.setBackground(new java.awt.Color(255, 255, 255));
        t3.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t3.setForeground(new java.awt.Color(204, 102, 0));
        t3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t3.setText("Tel#");
        t3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 190, 179, -1));

        p4.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p4.setForeground(new java.awt.Color(255, 153, 51));
        p4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p4.setText("Position");
        p4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 220, 204, -1));

        p3.setBackground(new java.awt.Color(255, 255, 255));
        p3.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p3.setForeground(new java.awt.Color(204, 102, 0));
        p3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p3.setText("Position");
        p3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 190, 204, -1));

        e8.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e8.setForeground(new java.awt.Color(255, 153, 51));
        e8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e8.setText("Email");
        e8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 188, -1));

        e7.setBackground(new java.awt.Color(255, 255, 255));
        e7.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e7.setForeground(new java.awt.Color(204, 102, 0));
        e7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e7.setText("Email");
        e7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 188, -1));

        e6.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e6.setForeground(new java.awt.Color(255, 153, 51));
        e6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e6.setText("Email");
        e6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 188, -1));

        e5.setBackground(new java.awt.Color(255, 255, 255));
        e5.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e5.setForeground(new java.awt.Color(204, 102, 0));
        e5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e5.setText("Email");
        e5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 188, -1));

        t5.setBackground(new java.awt.Color(255, 255, 255));
        t5.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t5.setForeground(new java.awt.Color(204, 102, 0));
        t5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t5.setText("Tel#");
        t5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 250, 179, -1));

        t6.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t6.setForeground(new java.awt.Color(255, 153, 51));
        t6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t6.setText("Tel#");
        t6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t6, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, 179, -1));

        t7.setBackground(new java.awt.Color(255, 255, 255));
        t7.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t7.setForeground(new java.awt.Color(204, 102, 0));
        t7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t7.setText("Tel#");
        t7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 310, 179, -1));

        t8.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t8.setForeground(new java.awt.Color(255, 153, 51));
        t8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t8.setText("Tel#");
        t8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t8, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 340, 179, -1));

        p8.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p8.setForeground(new java.awt.Color(255, 153, 51));
        p8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p8.setText("Position");
        p8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p8, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 340, 204, -1));

        p7.setBackground(new java.awt.Color(255, 255, 255));
        p7.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p7.setForeground(new java.awt.Color(204, 102, 0));
        p7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p7.setText("Position");
        p7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p7, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 310, 204, -1));

        p6.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p6.setForeground(new java.awt.Color(255, 153, 51));
        p6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p6.setText("Position");
        p6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p6, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 280, 204, -1));

        p5.setBackground(new java.awt.Color(255, 255, 255));
        p5.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p5.setForeground(new java.awt.Color(204, 102, 0));
        p5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p5.setText("Position");
        p5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 250, 204, -1));

        e10.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e10.setForeground(new java.awt.Color(255, 153, 51));
        e10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e10.setText("Email");
        e10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e10, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 188, -1));

        e9.setBackground(new java.awt.Color(255, 255, 255));
        e9.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        e9.setForeground(new java.awt.Color(204, 102, 0));
        e9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        e9.setText("Email");
        e9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(e9, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, 188, -1));

        t10.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t10.setForeground(new java.awt.Color(255, 153, 51));
        t10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t10.setText("Tel#");
        t10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t10, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 400, 179, -1));

        t9.setBackground(new java.awt.Color(255, 255, 255));
        t9.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        t9.setForeground(new java.awt.Color(204, 102, 0));
        t9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t9.setText("Tel#");
        t9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(t9, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 370, 179, -1));

        p10.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p10.setForeground(new java.awt.Color(255, 153, 51));
        p10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p10.setText("Position");
        p10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p10, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 400, 204, -1));

        p9.setBackground(new java.awt.Color(255, 255, 255));
        p9.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        p9.setForeground(new java.awt.Color(204, 102, 0));
        p9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        p9.setText("Position");
        p9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        jPanel1.add(p9, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 370, 204, -1));

        combo1.setBackground(new java.awt.Color(204, 102, 0));
        combo1.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 130, 80, 20));

        combo2.setBackground(new java.awt.Color(255, 153, 0));
        combo2.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 160, 80, 20));

        combo3.setBackground(new java.awt.Color(204, 102, 0));
        combo3.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 190, 80, 20));

        combo4.setBackground(new java.awt.Color(255, 153, 0));
        combo4.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 220, 80, 20));

        combo5.setBackground(new java.awt.Color(204, 102, 0));
        combo5.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 250, 80, 20));

        combo6.setBackground(new java.awt.Color(255, 153, 0));
        combo6.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo6, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 280, 80, 20));

        combo7.setBackground(new java.awt.Color(204, 102, 0));
        combo7.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo7, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 310, 80, 20));

        combo8.setBackground(new java.awt.Color(255, 153, 0));
        combo8.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo8, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 340, 80, 20));

        combo9.setBackground(new java.awt.Color(204, 102, 0));
        combo9.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jPanel1.add(combo9, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 370, 80, 20));

        remove10.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove10.setForeground(new java.awt.Color(255, 0, 51));
        remove10.setText("X");
        remove10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove10, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 400, -1, -1));

        remove1.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove1.setForeground(new java.awt.Color(255, 0, 51));
        remove1.setText("X");
        remove1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 130, -1, -1));

        remove2.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove2.setForeground(new java.awt.Color(255, 0, 51));
        remove2.setText("X");
        remove2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove2, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 160, -1, -1));

        remove3.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove3.setForeground(new java.awt.Color(255, 0, 51));
        remove3.setText("X");
        remove3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 190, -1, -1));

        remove4.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove4.setForeground(new java.awt.Color(255, 0, 51));
        remove4.setText("X");
        remove4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove4, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 220, -1, -1));

        remove5.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove5.setForeground(new java.awt.Color(255, 0, 51));
        remove5.setText("X");
        remove5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove5, new org.netbeans.lib.awtextra.AbsoluteConstraints(729, 250, 10, -1));

        remove6.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove6.setForeground(new java.awt.Color(255, 0, 51));
        remove6.setText("X");
        remove6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove6, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 280, -1, -1));

        remove7.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove7.setForeground(new java.awt.Color(255, 0, 51));
        remove7.setText("X");
        remove7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove7, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 310, -1, -1));

        remove8.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove8.setForeground(new java.awt.Color(255, 0, 51));
        remove8.setText("X");
        remove8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove8, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 340, -1, -1));

        remove9.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        remove9.setForeground(new java.awt.Color(255, 0, 51));
        remove9.setText("X");
        remove9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(remove9, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 370, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 478, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
    DefaultTableModel staffModel = Notifications.WarnData.getStaffModelForFlight(flightID);

    
    staffModel.setRowCount(0);

    
    for (JComboBox<String> combo : staffCombos) {
        String name = (String) combo.getSelectedItem();
        if (name != null && !name.isEmpty()) {
            for (int i = 0; i < employeeModel.getRowCount(); i++) {
                if (employeeModel.getValueAt(i, 1).toString().equals(name)) {
                    String id = employeeModel.getValueAt(i, 0).toString();
                    String pos = employeeModel.getValueAt(i, 5).toString();
                    String tel = employeeModel.getValueAt(i, 4).toString();
                    String email = employeeModel.getValueAt(i, 3).toString();
                    staffModel.addRow(new Object[]{id, name, pos, tel, email});
                    break;
                }
            }
        }
    }
    
    FlightOption fo = new FlightOption(mainGUI);
       fo.setVisible(true);
       fo.pack();
       
    staffAssigned sa = new staffAssigned();
    sa.setVisible(true);
    sa.pack();
    this.dispose();

    }//GEN-LAST:event_submitActionPerformed

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
       FlightOption fo = new FlightOption(mainGUI);
       fo.setVisible(true);
       fo.pack();
        this.dispose();
    }//GEN-LAST:event_cancelActionPerformed

  
    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel busCap;
    private javax.swing.JButton cancel;
    public javax.swing.JComboBox<String> combo1;
    public javax.swing.JComboBox<String> combo10;
    public javax.swing.JComboBox<String> combo2;
    public javax.swing.JComboBox<String> combo3;
    public javax.swing.JComboBox<String> combo4;
    public javax.swing.JComboBox<String> combo5;
    public javax.swing.JComboBox<String> combo6;
    public javax.swing.JComboBox<String> combo7;
    public javax.swing.JComboBox<String> combo8;
    public javax.swing.JComboBox<String> combo9;
    public javax.swing.JLabel e1;
    public javax.swing.JLabel e10;
    public javax.swing.JLabel e2;
    public javax.swing.JLabel e3;
    public javax.swing.JLabel e4;
    public javax.swing.JLabel e5;
    public javax.swing.JLabel e6;
    public javax.swing.JLabel e7;
    public javax.swing.JLabel e8;
    public javax.swing.JLabel e9;
    private javax.swing.JLabel ecoCap;
    private javax.swing.JComboBox<String> jComboBox4;
    public javax.swing.JLabel p1;
    public javax.swing.JLabel p10;
    public javax.swing.JLabel p2;
    public javax.swing.JLabel p3;
    public javax.swing.JLabel p4;
    public javax.swing.JLabel p5;
    public javax.swing.JLabel p6;
    public javax.swing.JLabel p7;
    public javax.swing.JLabel p8;
    public javax.swing.JLabel p9;
    private javax.swing.JLabel remove1;
    private javax.swing.JLabel remove10;
    private javax.swing.JLabel remove2;
    private javax.swing.JLabel remove3;
    private javax.swing.JLabel remove4;
    private javax.swing.JLabel remove5;
    private javax.swing.JLabel remove6;
    private javax.swing.JLabel remove7;
    private javax.swing.JLabel remove8;
    private javax.swing.JLabel remove9;
    private javax.swing.JButton submit;
    public javax.swing.JLabel t1;
    public javax.swing.JLabel t10;
    public javax.swing.JLabel t2;
    public javax.swing.JLabel t3;
    public javax.swing.JLabel t4;
    public javax.swing.JLabel t5;
    public javax.swing.JLabel t6;
    public javax.swing.JLabel t7;
    public javax.swing.JLabel t8;
    public javax.swing.JLabel t9;
    // End of variables declaration//GEN-END:variables
}
