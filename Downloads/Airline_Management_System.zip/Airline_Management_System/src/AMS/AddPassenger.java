package AMS;

import Notifications.BookCancel;
import Notifications.selectRow;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import Notifications.WarnData;
import javax.swing.JOptionPane;

public class AddPassenger extends javax.swing.JFrame {
private String flightID;
private Main_GUI mainGUI;
   
    public AddPassenger(Main_GUI mainGUI,  String flightID) {
        initComponents();
        this.mainGUI = mainGUI;
        this.flightID = flightID;
       addPassenger.setModel(Notifications.WarnData.getPassengerModelForFlight(flightID));
    }



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.JPanel a = new javax.swing.JPanel();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        Return = new javax.swing.JButton();
        ecoCap = new javax.swing.JLabel();
        busCap = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        addPassenger = new javax.swing.JTable();
        delete = new javax.swing.JButton();
        txt = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        a.setBackground(new java.awt.Color(0, 51, 51));
        a.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 102, 0), 2));
        a.setPreferredSize(new java.awt.Dimension(470, 474));

        jPanel2.setBackground(new java.awt.Color(204, 102, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Booked Passengers");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 695, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 55, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Return.setBackground(new java.awt.Color(204, 102, 0));
        Return.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        Return.setText("Return");
        Return.setPreferredSize(new java.awt.Dimension(114, 23));
        Return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnActionPerformed(evt);
            }
        });

        ecoCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        ecoCap.setForeground(new java.awt.Color(255, 255, 255));

        busCap.setFont(new java.awt.Font("Segoe UI Light", 3, 12)); // NOI18N
        busCap.setForeground(new java.awt.Color(255, 255, 255));

        addPassenger.setBackground(new java.awt.Color(0, 51, 51));
        addPassenger.setForeground(new java.awt.Color(255, 255, 255));
        addPassenger.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Tel#", "Email", "Ticket", "Seat", "Book Ref."
            }
        ));
        addPassenger.setGridColor(new java.awt.Color(204, 102, 0));
        addPassenger.setSelectionBackground(new java.awt.Color(204, 102, 0));
        jScrollPane1.setViewportView(addPassenger);

        delete.setBackground(new java.awt.Color(204, 0, 0));
        delete.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        delete.setText("Cancel Flight");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        txt.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        txt.setForeground(new java.awt.Color(204, 102, 0));
        txt.setText("Passenger");
        txt.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        javax.swing.GroupLayout aLayout = new javax.swing.GroupLayout(a);
        a.setLayout(aLayout);
        aLayout.setHorizontalGroup(
            aLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(aLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(aLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(aLayout.createSequentialGroup()
                        .addComponent(delete)
                        .addGap(41, 41, 41)
                        .addComponent(Return, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(aLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(aLayout.createSequentialGroup()
                            .addGap(292, 292, 292)
                            .addComponent(ecoCap, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(86, 86, 86)
                            .addComponent(busCap, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(txt)
                        .addGroup(aLayout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 673, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        aLayout.setVerticalGroup(
            aLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(txt)
                .addGap(2, 2, 2)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(aLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Return, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(128, 128, 128)
                .addGroup(aLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ecoCap)
                    .addComponent(busCap))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 460));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnActionPerformed
       FlightOption fo = new FlightOption(mainGUI);
       fo.setVisible(true);
       fo.pack();
       
        this.dispose();
    }//GEN-LAST:event_ReturnActionPerformed
 
    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
  if (addPassenger.getSelectedRow() == -1) {
      selectRow sr = new selectRow();
      sr.setVisible(true);
      sr.pack();
  } else {
        javax.swing.table.DefaultTableModel model = Notifications.WarnData.getPassengerModelForFlight(flightID);
        int selectedRow = addPassenger.getSelectedRow();
        model.removeRow(selectedRow);
        WarnData data = new WarnData();
        for (int i = selectedRow; i < data.registerSeatFlight(flightID).length - 1; i++){
            data.registerSeatFlight(flightID)[i] = data.registerSeatFlight(flightID)[i+1];
        }
        data.registerSeatFlight(flightID)[data.registerSeatFlight(flightID).length - 1] = "";
       
        BookCancel bc = new BookCancel();
            bc.pack();
            bc.setVisible(true);
            
  }
    }//GEN-LAST:event_deleteActionPerformed

    private void txtAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtAncestorAdded
        txt.setText(mainGUI.flightsTable.getValueAt(mainGUI.flightsTable.getSelectedRow(), 0).toString() + "'s Passenger");
    }//GEN-LAST:event_txtAncestorAdded

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddPassenger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddPassenger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddPassenger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddPassenger.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Return;
    public static javax.swing.JTable addPassenger;
    private javax.swing.JLabel busCap;
    private javax.swing.JButton delete;
    private javax.swing.JLabel ecoCap;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel txt;
    // End of variables declaration//GEN-END:variables
}
