package Notifications;

import java.util.HashMap;
import java.util.Random;
import javax.swing.table.DefaultTableModel;

public class WarnData {
    public static int flightCounter = 1;
    
    public static DefaultTableModel planeTableModel;
    
    public static DefaultTableModel airportTableModel;
    
    public static DefaultTableModel employeeTableModel;
    
    public static DefaultTableModel passengerTableModel;
    
    public static DefaultTableModel flightTableModel;
    
    public static HashMap<String, DefaultTableModel> flightPassengers = new HashMap<>();

   
    public static DefaultTableModel getPassengerModelForFlight(String flightID) {
        if (!flightPassengers.containsKey(flightID)) {
            flightPassengers.put(flightID, new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID", "Passenger Name", "Tel #", "Email", "Tikcet", "Seats", "Book Ref."}
            ));
        }
        return flightPassengers.get(flightID);
    }

    
    public static void removePassengerModel(String flightID) {
        flightPassengers.remove(flightID);
    }
    
    
    
public static java.util.HashMap<String, javax.swing.table.DefaultTableModel> flightStaff = new java.util.HashMap<>();


public static javax.swing.table.DefaultTableModel getStaffModelForFlight(String flightID) {
    if (!flightStaff.containsKey(flightID)) {
        flightStaff.put(flightID, new javax.swing.table.DefaultTableModel(
            new Object[][]{},
            new String[]{"ID", "Name", "Position", "Tel #", "Email"}
        ));
    }
    return flightStaff.get(flightID);
}


public static void removeStaffModel(String flightID) {
    flightStaff.remove(flightID);
}

public static HashMap<String, String[]> seat = new HashMap<>();

public static String[] registerSeatFlight(String FlightID){
          
        if (!seat.containsKey(FlightID)) {
            seat.put(FlightID, new String[120]);
       }
          for (int i = 0; i < seat.get(FlightID).length; i++) {
             if (seat.get(FlightID)[i] != null && !seat.get(FlightID)[i].isEmpty()){
                 continue;
             } else {
                 seat.get(FlightID)[i] = "";
             }
        }
    return seat.get(FlightID);
}

public static void removeSeatModel (String flightID) {
    seat.remove(flightID);
}



    
    public static String[][] dtime = new String [50][6];
    public static String[][] atime = new String [50][6];
    public static String[] ref = new String[100];
    
    
   public static String generatePassengerID(DefaultTableModel passengerTable) {
    int maxID = 0;

    for (int i = 0; i < passengerTable.getRowCount(); i++) {
        try {
            
            String idStr = passengerTable.getValueAt(i, 0).toString().substring(1); 
            int idNum = Integer.parseInt(idStr);
            if (idNum > maxID) {
                maxID = idNum;
            }
        } catch (Exception e) {
           
        }
    }

    
    int nextID = maxID + 1;
    return String.format("P%03d", nextID);
}
    
       public static String generateEmployeeID(DefaultTableModel employeeTable) {
    int maxID = 0;

    for (int i = 0; i < employeeTable.getRowCount(); i++) {
        try {
            String idStr = employeeTable.getValueAt(i, 0).toString().substring(1); 
            int idNum = Integer.parseInt(idStr);
            if (idNum > maxID) {
                maxID = idNum;
            }
        } catch (Exception e) {
            
        }
    }

    int nextID = maxID + 1;
    return String.format("E%03d", nextID);
}
    
    
    public static void DataStorage() {
        
        for (int i = 0; i < 25; i++) {
            for (int j = 0; j < 6; j++){
                if (dtime[i][j] != null && !dtime[i][j].isEmpty()) {
                continue;
            } else {
                dtime[i][j] = "";
            }
            }
        }
        
        for (int i = 0; i < 25; i++) {
            for (int j = 0; j < 6; j++){
                if (atime[i][j] != null && !atime[i][j].isEmpty()) {
                continue;
            } else {
                atime[i][j] = "";
            }
            }
        }
        
           for (int i = 0; i < 100; i++) {
             if (ref[i] != null && !ref[i].isEmpty()){
                 continue;
             } else {
                 ref[i] = "";
             }
        }
         
    }
    
     public static String generateReference() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder reference = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 6; i++) {
            int index = random.nextInt(characters.length());
            reference.append(characters.charAt(index));
        }

        return reference.toString();
    }
    
}
