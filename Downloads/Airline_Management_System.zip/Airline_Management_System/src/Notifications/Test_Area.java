
package Notifications;


public class Test_Area {
    public static void main(String[] args) {
       String test = "Test1";
       String test2 = "Test2";
        
        WarnData.registerSeatFlight("Flight1")[1] = test;
        WarnData.registerSeatFlight("Flight1")[2] = test2;
        
        
       System.out.println(WarnData.seat.get("Flight1")[1]);
       System.out.println(WarnData.seat.get("Flight1")[2]);
    }
}
